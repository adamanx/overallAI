import os
import logging
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Union, Optional, Tuple, Any, Callable
from src.time_series_db import TimeSeriesDatabase
from src.feature_engineering_pipeline import FeatureEngineeringPipeline
from src.ml_model_manager import MLModelManager

class BacktestEngine:
    """
    Backtesting engine for cryptocurrency trading strategies.
    Simulates trading on historical data to evaluate strategy performance.
    """
    
    def __init__(self, db_path=None):
        """
        Initialize the BacktestEngine.
        
        Args:
            db_path (str): Path to the SQLite database file
        """
        self.logger = logging.getLogger("backtest_engine")
        
        # Initialize database
        self.db = TimeSeriesDatabase(db_path)
        
        # Initialize feature engineering pipeline
        self.feature_pipeline = FeatureEngineeringPipeline(db_path)
        
        # Initialize ML model manager
        self.model_manager = MLModelManager()
        
        # Create directories if they don't exist
        os.makedirs("backtest_results", exist_ok=True)
        
        self.logger.info("BacktestEngine initialized")
    
    def run_backtest(self, strategy, symbol, start_date, end_date, timeframe='1Min',
                    initial_capital=10000.0, commission=0.001, slippage=0.0005):
        """
        Run a backtest for a trading strategy.
        
        Args:
            strategy: Trading strategy instance
            symbol (str): Cryptocurrency symbol
            start_date (str): Start date in YYYY-MM-DD format
            end_date (str): End date in YYYY-MM-DD format
            timeframe (str): Timeframe of the data
            initial_capital (float): Initial capital for the backtest
            commission (float): Commission rate per trade
            slippage (float): Slippage rate per trade
            
        Returns:
            Dict with backtest results
        """
        try:
            self.logger.info(f"Running backtest for {symbol} from {start_date} to {end_date}")
            
            # Convert dates to timestamps
            start_timestamp = int(datetime.strptime(start_date, '%Y-%m-%d').timestamp() * 1000)
            end_timestamp = int(datetime.strptime(end_date, '%Y-%m-%d').timestamp() * 1000)
            
            # Get historical data
            df = self.db.get_bars(symbol, start_timestamp, end_timestamp, timeframe)
            
            if df.empty:
                self.logger.warning(f"No data found for {symbol}")
                return {}
            
            # Generate features
            features_df = self.feature_pipeline.process_symbol(
                symbol, start_timestamp, end_timestamp, timeframe,
                normalize=False, save_to_file=False
            )
            
            if features_df.empty:
                self.logger.warning(f"No features generated for {symbol}")
                return {}
            
            # Initialize strategy
            strategy.initialize(
                symbol=symbol,
                timeframe=timeframe,
                initial_capital=initial_capital,
                commission=commission,
                slippage=slippage
            )
            
            # Run backtest
            results = self._run_backtest_simulation(strategy, features_df)
            
            # Calculate performance metrics
            performance = self._calculate_performance_metrics(results)
            
            # Save results
            self._save_backtest_results(strategy, symbol, timeframe, results, performance)
            
            return {
                'results': results,
                'performance': performance
            }
            
        except Exception as e:
            self.logger.error(f"Error running backtest: {e}", exc_info=True)
            return {}
    
    def _run_backtest_simulation(self, strategy, features_df):
        """
        Run the backtest simulation.
        
        Args:
            strategy: Trading strategy instance
            features_df: DataFrame with features
            
        Returns:
            Dict with simulation results
        """
        try:
            self.logger.info("Running backtest simulation")
            
            # Initialize results
            results = {
                'timestamp': [],
                'price': [],
                'position': [],
                'cash': [],
                'equity': [],
                'returns': [],
                'trade_type': [],
                'trade_price': [],
                'trade_size': [],
                'trade_cost': [],
                'trade_pnl': []
            }
            
            # Initialize variables
            position = 0
            cash = strategy.initial_capital
            equity = cash
            last_equity = equity
            
            # Iterate through each bar
            for idx, row in features_df.iterrows():
                # Update strategy with current bar
                strategy.on_bar(idx, row)
                
                # Get current price
                price = row['close']
                
                # Get strategy signals
                signals = strategy.generate_signals(idx, row)
                
                # Process signals
                for signal in signals:
                    # Get signal details
                    signal_type = signal['type']  # 'buy', 'sell', 'exit'
                    signal_size = signal['size']  # Number of units
                    
                    # Calculate trade details
                    trade_price = price * (1 + strategy.slippage if signal_type == 'buy' else 1 - strategy.slippage)
                    trade_cost = trade_price * signal_size * strategy.commission
                    
                    # Execute trade
                    if signal_type == 'buy':
                        # Check if we have enough cash
                        max_size = cash / (trade_price * (1 + strategy.commission))
                        actual_size = min(signal_size, max_size)
                        
                        # Update position and cash
                        position += actual_size
                        cash -= (trade_price * actual_size + trade_cost)
                        
                        # Record trade
                        results['trade_type'].append('buy')
                        results['trade_price'].append(trade_price)
                        results['trade_size'].append(actual_size)
                        results['trade_cost'].append(trade_cost)
                        results['trade_pnl'].append(0)
                        
                    elif signal_type == 'sell':
                        # Check if we have enough position
                        actual_size = min(signal_size, position)
                        
                        # Calculate PnL
                        trade_pnl = (trade_price - strategy.avg_entry_price) * actual_size - trade_cost
                        
                        # Update position and cash
                        position -= actual_size
                        cash += (trade_price * actual_size - trade_cost)
                        
                        # Record trade
                        results['trade_type'].append('sell')
                        results['trade_price'].append(trade_price)
                        results['trade_size'].append(actual_size)
                        results['trade_cost'].append(trade_cost)
                        results['trade_pnl'].append(trade_pnl)
                        
                    elif signal_type == 'exit':
                        # Exit all position
                        if position > 0:
                            # Calculate PnL
                            trade_pnl = (trade_price - strategy.avg_entry_price) * position - trade_cost
                            
                            # Update position and cash
                            cash += (trade_price * position - trade_cost)
                            position = 0
                            
                            # Record trade
                            results['trade_type'].append('exit')
                            results['trade_price'].append(trade_price)
                            results['trade_size'].append(position)
                            results['trade_cost'].append(trade_cost)
                            results['trade_pnl'].append(trade_pnl)
                
                # Calculate equity
                equity = cash + position * price
                
                # Calculate returns
                returns = (equity / last_equity) - 1 if last_equity > 0 else 0
                last_equity = equity
                
                # Record results
                results['timestamp'].append(idx)
                results['price'].append(price)
                results['position'].append(position)
                results['cash'].append(cash)
                results['equity'].append(equity)
                results['returns'].append(returns)
            
            # Convert results to DataFrame
            results_df = pd.DataFrame({
                'timestamp': results['timestamp'],
                'price': results['price'],
                'position': results['position'],
                'cash': results['cash'],
                'equity': results['equity'],
                'returns': results['returns']
            })
            
            # Create trades DataFrame
            if results['trade_type']:
                trades_df = pd.DataFrame({
                    'type': results['trade_type'],
                    'price': results['trade_price'],
                    'size': results['trade_size'],
                    'cost': results['trade_cost'],
                    'pnl': results['trade_pnl']
                })
            else:
                trades_df = pd.DataFrame(columns=['type', 'price', 'size', 'cost', 'pnl'])
            
            return {
                'results_df': results_df,
                'trades_df': trades_df,
                'final_equity': equity,
                'final_position': position,
                'final_cash': cash
            }
            
        except Exception as e:
            self.logger.error(f"Error running backtest simulation: {e}", exc_info=True)
            return {}
    
    def _calculate_performance_metrics(self, results):
        """
        Calculate performance metrics for the backtest.
        
        Args:
            results: Dict with simulation results
            
        Returns:
            Dict with performance metrics
        """
        try:
            self.logger.info("Calculating performance metrics")
            
            # Get results DataFrame
            results_df = results.get('results_df')
            trades_df = results.get('trades_df')
            
            if results_df is None or results_df.empty:
                self.logger.warning("No results to calculate performance metrics")
                return {}
            
            # Calculate returns
            initial_equity = results_df['equity'].iloc[0]
            final_equity = results_df['equity'].iloc[-1]
            total_return = (final_equity / initial_equity) - 1
            
            # Calculate annualized return
            days = (results_df['timestamp'].iloc[-1] - results_df['timestamp'].iloc[0]).days
            if days > 0:
                annual_return = (1 + total_return) ** (365 / days) - 1
            else:
                annual_return = 0
            
            # Calculate drawdown
            results_df['peak'] = results_df['equity'].cummax()
            results_df['drawdown'] = (results_df['equity'] / results_df['peak']) - 1
            max_drawdown = results_df['drawdown'].min()
            
            # Calculate Sharpe ratio
            if results_df['returns'].std() > 0:
                sharpe_ratio = results_df['returns'].mean() / results_df['returns'].std() * np.sqrt(252)
            else:
                sharpe_ratio = 0
            
            # Calculate trade statistics
            if not trades_df.empty:
                num_trades = len(trades_df)
                profitable_trades = len(trades_df[trades_df['pnl'] > 0])
                win_rate = profitable_trades / num_trades if num_trades > 0 else 0
                avg_profit = trades_df[trades_df['pnl'] > 0]['pnl'].mean() if profitable_trades > 0 else 0
                avg_loss = trades_df[trades_df['pnl'] <= 0]['pnl'].mean() if num_trades - profitable_trades > 0 else 0
                profit_factor = abs(trades_df[trades_df['pnl'] > 0]['pnl'].sum() / trades_df[trades_df['pnl'] <= 0]['pnl'].sum()) if trades_df[trades_df['pnl'] <= 0]['pnl'].sum() != 0 else float('inf')
            else:
                num_trades = 0
                win_rate = 0
                avg_profit = 0
                avg_loss = 0
                profit_factor = 0
            
            # Calculate other metrics
            volatility = results_df['returns'].std() * np.sqrt(252)
            sortino_ratio = results_df['returns'].mean() / results_df[results_df['returns'] < 0]['returns'].std() * np.sqrt(252) if len(results_df[results_df['returns'] < 0]) > 0 and results_df[results_df['returns'] < 0]['returns'].std() > 0 else 0
            
            # Compile performance metrics
            performance = {
                'initial_equity': initial_equity,
                'final_equity': final_equity,
                'total_return': total_return,
                'annual_return': annual_return,
                'max_drawdown': max_drawdown,
                'sharpe_ratio': sharpe_ratio,
                'sortino_ratio': sortino_ratio,
                'volatility': volatility,
                'num_trades': num_trades,
                'win_rate': win_rate,
                'avg_profit': avg_profit,
                'avg_loss': avg_loss,
                'profit_factor': profit_factor
            }
            
            self.logger.info(f"Performance metrics: {performance}")
            
            return performance
            
        except Exception as e:
            self.logger.error(f"Error calculating performance metrics: {e}", exc_info=True)
            return {}
    
    def _save_backtest_results(self, strategy, symbol, timeframe, results, performance):
        """
        Save backtest results to files.
        
        Args:
            strategy: Trading strategy instance
            symbol (str): Cryptocurrency symbol
            timeframe (str): Timeframe of the data
            results: Dict with simulation results
            performance: Dict with performance metrics
            
        Returns:
            Dict with saved file paths
        """
        try:
            self.logger.info("Saving backtest results")
            
            # Generate timestamp
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            
            # Generate base filename
            base_filename = f"{symbol.replace('/', '_')}_{timeframe}_{strategy.name}_{timestamp}"
            
            # Save results DataFrame
            results_file = f"backtest_results/{base_filename}_results.csv"
            results['results_df'].to_csv(results_file)
            
            # Save trades DataFrame
            trades_file = f"backtest_results/{base_filename}_trades.csv"
            results['trades_df'].to_csv(trades_file)
            
            # Save performance metrics
            import json
            performance_file = f"backtest_results/{base_filename}_performance.json"
            with open(performance_file, 'w') as f:
                json.dump(performance, f, indent=4)
            
            # Save strategy configuration
            config_file = f"backtest_results/{base_filename}_config.json"
            with open(config_file, 'w') as f:
                json.dump(strategy.get_config(), f, indent=4)
            
            self.logger.info(f"Saved backtest results to {results_file}, {trades_file}, {performance_file}, {config_file}")
            
            return {
                'results_file': results_file,
                'trades_file': trades_file,
                'performance_file': performance_file,
                'config_file': config_file
            }
            
        except Exception as e:
            self.logger.error(f"Error saving backtest results: {e}", exc_info=True)
            return {}
    
    def compare_strategies(self, strategies, symbol, start_date, end_date, timeframe='1Min',
                         initial_capital=10000.0, commission=0.001, slippage=0.0005):
        """
        Compare multiple trading strategies.
        
        Args:
            strategies (list): List of trading strategy instances
            symbol (str): Cryptocurrency symbol
            start_date (str): Start date in YYYY-MM-DD format
            end_date (str): End date in YYYY-MM-DD format
            timeframe (str): Timeframe of the data
            initial_capital (float): Initial capital for the backtest
            commission (float): Commission rate per trade
            slippage (float): Slippage rate per trade
            
        Returns:
            Dict with comparison results
        """
        try:
            self.logger.info(f"Comparing {len(strategies)} strategies for {symbol}")
            
            # Run backtest for each strategy
            results = {}
            
            for strategy in strategies:
                strategy_name = strategy.name
                self.logger.info(f"Running backtest for strategy: {strategy_name}")
                
                # Run backtest
                backtest_results = self.run_backtest(
                    strategy, symbol, start_date, end_date, timeframe,
                    initial_capital, commission, slippage
                )
                
                if backtest_results:
                    results[strategy_name] = backtest_results
            
            # Compare performance metrics
            comparison = self._compare_performance_metrics(results)
            
            # Save comparison results
            self._save_comparison_results(symbol, timeframe, comparison)
            
            return comparison
            
        except Exception as e:
            self.logger.error(f"Error comparing strategies: {e}", exc_info=True)
            return {}
    
    def _compare_performance_metrics(self, results):
        """
        Compare performance metrics for multiple strategies.
        
        Args:
            results: Dict with backtest results for each strategy
            
        Returns:
            Dict with comparison results
        """
        try:
            self.logger.info("Comparing performance metrics")
            
            # Initialize comparison
            comparison = {
                'strategies': list(results.keys()),
                'metrics': {}
            }
            
            # Define metrics to compare
            metrics = [
                'total_return', 'annual_return', 'max_drawdown', 'sharpe_ratio',
                'sortino_ratio', 'volatility', 'num_trades', 'win_rate',
                'profit_factor'
            ]
            
            # Compare each metric
            for metric in metrics:
                comparison['metrics'][metric] = {}
                
                for strategy_name, backtest_results in results.items():
                    performance = backtest_results.get('performance', {})
                    comparison['metrics'][metric][strategy_name] = performance.get(metric, 0)
            
            # Determine best strategy for each metric
            comparison['best_strategy'] = {}
            
            for metric in metrics:
                if metric in ['max_drawdown', 'volatility']:
                    # Lower is better
                    best_strategy = min(
                        comparison['metrics'][metric].items(),
                        key=lambda x: x[1]
                    )[0]
                else:
                    # Higher is better
                    best_strategy = max(
                        comparison['metrics'][metric].items(),
                        key=lambda x: x[1]
                    )[0]
                
                comparison['best_strategy'][metric] = best_strategy
            
            # Determine overall best strategy
            # Simple scoring: count how many times each strategy is the best
            scores = {}
            for strategy_name in comparison['strategies']:
                scores[strategy_name] = sum(
                    1 for metric, best in comparison['best_strategy'].items()
                    if best == strategy_name
                )
            
            comparison['overall_best_strategy'] = max(
                scores.items(),
                key=lambda x: x[1]
            )[0]
            
            self.logger.info(f"Overall best strategy: {comparison['overall_best_strategy']}")
            
            return comparison
            
        except Exception as e:
            self.logger.error(f"Error comparing performance metrics: {e}", exc_info=True)
            return {}
    
    def _save_comparison_results(self, symbol, timeframe, comparison):
        """
        Save strategy comparison results to file.
        
        Args:
            symbol (str): Cryptocurrency symbol
            timeframe (str): Timeframe of the data
            comparison: Dict with comparison results
            
        Returns:
            Dict with saved file path
        """
        try:
            self.logger.info("Saving comparison results")
            
            # Generate timestamp
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            
            # Generate filename
            filename = f"backtest_results/{symbol.replace('/', '_')}_{timeframe}_comparison_{timestamp}.json"
            
            # Save comparison results
            import json
            with open(filename, 'w') as f:
                json.dump(comparison, f, indent=4)
            
            self.logger.info(f"Saved comparison results to {filename}")
            
            return {'comparison_file': filename}
            
        except Exception as e:
            self.logger.error(f"Error saving comparison results: {e}", exc_info=True)
            return {}

class TradingStrategy:
    """
    Base class for trading strategies.
    Defines the interface for all trading strategies.
    """
    
    def __init__(self, name):
        """
        Initialize the TradingStrategy.
        
        Args:
            name (str): Strategy name
        """
        self.logger = logging.getLogger(f"strategy.{name}")
        self.name = name
        
        # Strategy parameters
        self.symbol = None
        self.timeframe = None
        self.initial_capital = 0.0
        self.commission = 0.0
        self.slippage = 0.0
        
        # Trading state
        self.position = 0.0
        self.cash = 0.0
        self.equity = 0.0
        self.avg_entry_price = 0.0
        
        # Trading history
        self.trades = []
        
        self.logger.info(f"TradingStrategy '{name}' initialized")
    
    def initialize(self, symbol, timeframe, initial_capital=10000.0, commission=0.001, slippage=0.0005):
        """
        Initialize the strategy with parameters.
        
        Args:
            symbol (str): Cryptocurrency symbol
            timeframe (str): Timeframe of the data
            initial_capital (float): Initial capital for the backtest
            commission (float): Commission rate per trade
            slippage (float): Slippage rate per trade
        """
        self.symbol = symbol
        self.timeframe = timeframe
        self.initial_capital = initial_capital
        self.commission = commission
        self.slippage = slippage
        
        # Reset trading state
        self.position = 0.0
        self.cash = initial_capital
        self.equity = initial_capital
        self.avg_entry_price = 0.0
        
        # Reset trading history
        self.trades = []
        
        self.logger.info(f"Strategy initialized for {symbol} {timeframe}")
    
    def on_bar(self, timestamp, bar):
        """
        Process a new bar.
        
        Args:
            timestamp: Bar timestamp
            bar: Bar data
        """
        # To be implemented by subclasses
        pass
    
    def generate_signals(self, timestamp, bar):
        """
        Generate trading signals.
        
        Args:
            timestamp: Bar timestamp
            bar: Bar data
            
        Returns:
            List of signal dictionaries
        """
        # To be implemented by subclasses
        return []
    
    def get_config(self):
        """
        Get strategy configuration.
        
        Returns:
            Dict with strategy configuration
        """
        return {
            'name': self.name,
            'symbol': self.symbol,
            'timeframe': self.timeframe,
            'initial_capital': self.initial_capital,
            'commission': self.commission,
            'slippage': self.slippage
        }

class SpikeDetectionStrategy(TradingStrategy):
    """
    Trading strategy based on spike detection.
    Uses machine learning models to detect and trade price spikes.
    """
    
    def __init__(self, name="SpikeDetection", threshold=0.7, holding_period=5, stop_loss=0.02, take_profit=0.05):
        """
        Initialize the SpikeDetectionStrategy.
        
        Args:
            name (str): Strategy name
            threshold (float): Probability threshold for spike detection
            holding_period (int): Number of bars to hold position
            stop_loss (float): Stop loss percentage
            take_profit (float): Take profit percentage
        """
        super().__init__(name)
        
        # Strategy parameters
        self.threshold = threshold
        self.holding_period = holding_period
        self.stop_loss = stop_loss
        self.take_profit = take_profit
        
        # Strategy state
        self.entry_price = 0.0
        self.entry_time = None
        self.bars_held = 0
        self.stop_price = 0.0
        self.target_price = 0.0
        
        # ML model manager
        self.model_manager = MLModelManager()
        
        # Feature engineering pipeline
        self.feature_pipeline = FeatureEngineeringPipeline()
        
        # Models
        self.models = {}
        
        self.logger.info(f"SpikeDetectionStrategy initialized with threshold={threshold}, holding_period={holding_period}")
    
    def initialize(self, symbol, timeframe, initial_capital=10000.0, commission=0.001, slippage=0.0005):
        """
        Initialize the strategy with parameters.
        
        Args:
            symbol (str): Cryptocurrency symbol
            timeframe (str): Timeframe of the data
            initial_capital (float): Initial capital for the backtest
            commission (float): Commission rate per trade
            slippage (float): Slippage rate per trade
        """
        super().initialize(symbol, timeframe, initial_capital, commission, slippage)
        
        # Load models
        self.models = self.model_manager.get_best_models(symbol, timeframe)
        
        if not self.models:
            self.logger.warning(f"No models found for {symbol} {timeframe}")
        else:
            self.logger.info(f"Loaded {len(self.models)} models for {symbol} {timeframe}")
    
    def on_bar(self, timestamp, bar):
        """
        Process a new bar.
        
        Args:
            timestamp: Bar timestamp
            bar: Bar data
        """
        # Update bars held
        if self.position != 0:
            self.bars_held += 1
    
    def generate_signals(self, timestamp, bar):
        """
        Generate trading signals.
        
        Args:
            timestamp: Bar timestamp
            bar: Bar data
            
        Returns:
            List of signal dictionaries
        """
        signals = []
        
        # Check if we have models
        if not self.models:
            return signals
        
        # Get current price
        price = bar['close']
        
        # Check for exit conditions if we have a position
        if self.position > 0:
            # Check stop loss
            if price <= self.stop_price:
                signals.append({
                    'type': 'exit',
                    'reason': 'stop_loss',
                    'size': self.position
                })
                self.logger.info(f"Stop loss triggered at {price}")
                return signals
            
            # Check take profit
            if price >= self.target_price:
                signals.append({
                    'type': 'exit',
                    'reason': 'take_profit',
                    'size': self.position
                })
                self.logger.info(f"Take profit triggered at {price}")
                return signals
            
            # Check holding period
            if self.bars_held >= self.holding_period:
                signals.append({
                    'type': 'exit',
                    'reason': 'holding_period',
                    'size': self.position
                })
                self.logger.info(f"Holding period reached ({self.bars_held} bars)")
                return signals
        
        # If we already have a position, don't enter a new one
        if self.position > 0:
            return signals
        
        # Make predictions
        features_df = pd.DataFrame([bar])
        predictions = self.model_manager.predict_with_models(features_df, self.models)
        
        # Check for spike signals
        if 'spike_binary' in predictions and len(predictions['spike_binary']) > 0:
            spike_prob = predictions['spike_binary'][0]
            
            # Check if probability exceeds threshold
            if spike_prob > self.threshold:
                # Check direction if available
                direction = 1  # Default to long
                if 'spike_multi' in predictions and len(predictions['spike_multi']) > 0:
                    # Multi-class prediction: -1 (negative), 0 (no spike), 1 (positive)
                    if predictions['spike_multi'][0] == -1:
                        direction = -1  # Short
                
                # Only take long positions for now
                if direction > 0:
                    # Calculate position size (use 50% of available capital)
                    position_size = (self.cash * 0.5) / price
                    
                    # Generate buy signal
                    signals.append({
                        'type': 'buy',
                        'reason': 'spike_detected',
                        'size': position_size,
                        'probability': spike_prob
                    })
                    
                    # Set entry price and time
                    self.entry_price = price
                    self.entry_time = timestamp
                    self.bars_held = 0
                    
                    # Set stop loss and take profit prices
                    self.stop_price = price * (1 - self.stop_loss)
                    self.target_price = price * (1 + self.take_profit)
                    
                    self.logger.info(f"Spike detected with probability {spike_prob:.2f}, buying at {price}")
        
        return signals
    
    def get_config(self):
        """
        Get strategy configuration.
        
        Returns:
            Dict with strategy configuration
        """
        config = super().get_config()
        config.update({
            'threshold': self.threshold,
            'holding_period': self.holding_period,
            'stop_loss': self.stop_loss,
            'take_profit': self.take_profit
        })
        return config

class MovingAverageCrossoverStrategy(TradingStrategy):
    """
    Trading strategy based on moving average crossover.
    Generates signals when fast MA crosses over slow MA.
    """
    
    def __init__(self, name="MACrossover", fast_period=20, slow_period=50, stop_loss=0.02, take_profit=0.05):
        """
        Initialize the MovingAverageCrossoverStrategy.
        
        Args:
            name (str): Strategy name
            fast_period (int): Fast moving average period
            slow_period (int): Slow moving average period
            stop_loss (float): Stop loss percentage
            take_profit (float): Take profit percentage
        """
        super().__init__(name)
        
        # Strategy parameters
        self.fast_period = fast_period
        self.slow_period = slow_period
        self.stop_loss = stop_loss
        self.take_profit = take_profit
        
        # Strategy state
        self.prices = []
        self.fast_ma = []
        self.slow_ma = []
        self.last_signal = None
        self.entry_price = 0.0
        self.stop_price = 0.0
        self.target_price = 0.0
        
        self.logger.info(f"MovingAverageCrossoverStrategy initialized with fast_period={fast_period}, slow_period={slow_period}")
    
    def initialize(self, symbol, timeframe, initial_capital=10000.0, commission=0.001, slippage=0.0005):
        """
        Initialize the strategy with parameters.
        
        Args:
            symbol (str): Cryptocurrency symbol
            timeframe (str): Timeframe of the data
            initial_capital (float): Initial capital for the backtest
            commission (float): Commission rate per trade
            slippage (float): Slippage rate per trade
        """
        super().initialize(symbol, timeframe, initial_capital, commission, slippage)
        
        # Reset strategy state
        self.prices = []
        self.fast_ma = []
        self.slow_ma = []
        self.last_signal = None
        self.entry_price = 0.0
        self.stop_price = 0.0
        self.target_price = 0.0
    
    def on_bar(self, timestamp, bar):
        """
        Process a new bar.
        
        Args:
            timestamp: Bar timestamp
            bar: Bar data
        """
        super().on_bar(timestamp, bar)
        
        # Get current price
        price = bar['close']
        
        # Update price history
        self.prices.append(price)
        
        # Calculate moving averages
        if len(self.prices) >= self.slow_period:
            # Calculate fast MA
            fast_ma = sum(self.prices[-self.fast_period:]) / self.fast_period
            self.fast_ma.append(fast_ma)
            
            # Calculate slow MA
            slow_ma = sum(self.prices[-self.slow_period:]) / self.slow_period
            self.slow_ma.append(slow_ma)
            
            # Trim history to save memory
            if len(self.prices) > self.slow_period * 2:
                self.prices.pop(0)
                if len(self.fast_ma) > self.slow_period:
                    self.fast_ma.pop(0)
                if len(self.slow_ma) > self.slow_period:
                    self.slow_ma.pop(0)
    
    def generate_signals(self, timestamp, bar):
        """
        Generate trading signals.
        
        Args:
            timestamp: Bar timestamp
            bar: Bar data
            
        Returns:
            List of signal dictionaries
        """
        signals = []
        
        # Get current price
        price = bar['close']
        
        # Check if we have enough data
        if len(self.fast_ma) < 2 or len(self.slow_ma) < 2:
            return signals
        
        # Check for exit conditions if we have a position
        if self.position > 0:
            # Check stop loss
            if price <= self.stop_price:
                signals.append({
                    'type': 'exit',
                    'reason': 'stop_loss',
                    'size': self.position
                })
                self.logger.info(f"Stop loss triggered at {price}")
                return signals
            
            # Check take profit
            if price >= self.target_price:
                signals.append({
                    'type': 'exit',
                    'reason': 'take_profit',
                    'size': self.position
                })
                self.logger.info(f"Take profit triggered at {price}")
                return signals
            
            # Check for sell signal (fast MA crosses below slow MA)
            if self.fast_ma[-2] >= self.slow_ma[-2] and self.fast_ma[-1] < self.slow_ma[-1]:
                signals.append({
                    'type': 'exit',
                    'reason': 'sell_signal',
                    'size': self.position
                })
                self.logger.info(f"Sell signal generated at {price}")
                return signals
        
        # Check for buy signal (fast MA crosses above slow MA)
        if self.position == 0 and self.fast_ma[-2] <= self.slow_ma[-2] and self.fast_ma[-1] > self.slow_ma[-1]:
            # Calculate position size (use 50% of available capital)
            position_size = (self.cash * 0.5) / price
            
            # Generate buy signal
            signals.append({
                'type': 'buy',
                'reason': 'buy_signal',
                'size': position_size
            })
            
            # Set entry price
            self.entry_price = price
            
            # Set stop loss and take profit prices
            self.stop_price = price * (1 - self.stop_loss)
            self.target_price = price * (1 + self.take_profit)
            
            self.logger.info(f"Buy signal generated at {price}")
        
        return signals
    
    def get_config(self):
        """
        Get strategy configuration.
        
        Returns:
            Dict with strategy configuration
        """
        config = super().get_config()
        config.update({
            'fast_period': self.fast_period,
            'slow_period': self.slow_period,
            'stop_loss': self.stop_loss,
            'take_profit': self.take_profit
        })
        return config

# Example usage
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Create backtest engine
    backtest_engine = BacktestEngine()
    
    # Create strategies
    spike_strategy = SpikeDetectionStrategy(threshold=0.7, holding_period=5)
    ma_strategy = MovingAverageCrossoverStrategy(fast_period=20, slow_period=50)
    
    # Run backtest for a single strategy
    symbol = "BTC/USD"
    start_date = "2023-01-01"
    end_date = "2023-01-31"
    
    results = backtest_engine.run_backtest(
        spike_strategy, symbol, start_date, end_date, timeframe="1H",
        initial_capital=10000.0, commission=0.001, slippage=0.0005
    )
    
    # Compare strategies
    strategies = [spike_strategy, ma_strategy]
    comparison = backtest_engine.compare_strategies(
        strategies, symbol, start_date, end_date, timeframe="1H"
    )
    
    # Print results
    if results:
        performance = results.get('performance', {})
        print(f"Backtest results for {symbol}:")
        print(f"Total return: {performance.get('total_return', 0) * 100:.2f}%")
        print(f"Sharpe ratio: {performance.get('sharpe_ratio', 0):.2f}")
        print(f"Max drawdown: {performance.get('max_drawdown', 0) * 100:.2f}%")
        print(f"Win rate: {performance.get('win_rate', 0) * 100:.2f}%")
    
    if comparison:
        print(f"\nStrategy comparison:")
        print(f"Overall best strategy: {comparison.get('overall_best_strategy', '')}")
