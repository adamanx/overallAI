import os
import logging
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import json
from src.backtest_engine import BacktestEngine
from src.trading_strategy import AdvancedTradingStrategy, AdaptiveTradingStrategy
from src.backtest_engine import SpikeDetectionStrategy, MovingAverageCrossoverStrategy
from src.time_series_db import TimeSeriesDatabase
from src.feature_engineering_pipeline import FeatureEngineeringPipeline
from src.ml_model_manager import MLModelManager

class PerformanceEvaluator:
    """
    Performance evaluation system for cryptocurrency trading strategies.
    Runs backtests, calculates metrics, and generates reports.
    """
    
    def __init__(self, output_dir="performance_results"):
        """
        Initialize the PerformanceEvaluator.
        
        Args:
            output_dir: Directory to save performance results
        """
        self.logger = logging.getLogger("performance_evaluator")
        
        # Create output directory
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
        # Initialize components
        self.backtest_engine = BacktestEngine()
        self.db = TimeSeriesDatabase()
        self.feature_pipeline = FeatureEngineeringPipeline()
        self.model_manager = MLModelManager()
        
        self.logger.info("PerformanceEvaluator initialized")
    
    def run_strategy_evaluation(self, strategy, symbol, start_date, end_date, 
                              timeframe='1Min', initial_capital=10000.0,
                              commission=0.001, slippage=0.0005):
        """
        Run a comprehensive evaluation of a trading strategy.
        
        Args:
            strategy: Trading strategy instance
            symbol: Cryptocurrency symbol
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            timeframe: Timeframe of the data
            initial_capital: Initial capital for the backtest
            commission: Commission rate per trade
            slippage: Slippage rate per trade
            
        Returns:
            Dict with evaluation results
        """
        try:
            self.logger.info(f"Evaluating {strategy.name} on {symbol} from {start_date} to {end_date}")
            
            # Run backtest
            backtest_results = self.backtest_engine.run_backtest(
                strategy, symbol, start_date, end_date, timeframe,
                initial_capital, commission, slippage
            )
            
            if not backtest_results:
                self.logger.warning(f"No backtest results for {strategy.name} on {symbol}")
                return {}
            
            # Extract performance metrics
            performance = backtest_results.get('performance', {})
            
            # Generate performance report
            report = self._generate_performance_report(strategy, symbol, timeframe, performance)
            
            # Generate equity curve chart
            results_df = backtest_results.get('results', {}).get('results_df')
            if results_df is not None and not results_df.empty:
                chart_path = self._generate_equity_curve(
                    results_df, strategy.name, symbol, timeframe
                )
                report['equity_curve_chart'] = chart_path
            
            # Save report
            report_path = self._save_performance_report(report, strategy.name, symbol, timeframe)
            
            return {
                'backtest_results': backtest_results,
                'report': report,
                'report_path': report_path
            }
            
        except Exception as e:
            self.logger.error(f"Error evaluating strategy: {e}", exc_info=True)
            return {}
    
    def _generate_performance_report(self, strategy, symbol, timeframe, performance):
        """
        Generate a performance report for a strategy.
        
        Args:
            strategy: Trading strategy instance
            symbol: Cryptocurrency symbol
            timeframe: Timeframe of the data
            performance: Dict with performance metrics
            
        Returns:
            Dict with performance report
        """
        try:
            # Format metrics for report
            report = {
                'strategy_name': strategy.name,
                'symbol': symbol,
                'timeframe': timeframe,
                'evaluation_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'metrics': {
                    'returns': {
                        'total_return': f"{performance.get('total_return', 0) * 100:.2f}%",
                        'annual_return': f"{performance.get('annual_return', 0) * 100:.2f}%",
                        'initial_equity': f"${performance.get('initial_equity', 0):.2f}",
                        'final_equity': f"${performance.get('final_equity', 0):.2f}"
                    },
                    'risk': {
                        'max_drawdown': f"{performance.get('max_drawdown', 0) * 100:.2f}%",
                        'volatility': f"{performance.get('volatility', 0) * 100:.2f}%",
                        'sharpe_ratio': f"{performance.get('sharpe_ratio', 0):.2f}",
                        'sortino_ratio': f"{performance.get('sortino_ratio', 0):.2f}"
                    },
                    'trading': {
                        'num_trades': performance.get('num_trades', 0),
                        'win_rate': f"{performance.get('win_rate', 0) * 100:.2f}%",
                        'profit_factor': f"{performance.get('profit_factor', 0):.2f}",
                        'avg_profit': f"${performance.get('avg_profit', 0):.2f}",
                        'avg_loss': f"${performance.get('avg_loss', 0):.2f}"
                    }
                },
                'strategy_config': strategy.get_config()
            }
            
            return report
            
        except Exception as e:
            self.logger.error(f"Error generating performance report: {e}", exc_info=True)
            return {}
    
    def _generate_equity_curve(self, results_df, strategy_name, symbol, timeframe):
        """
        Generate an equity curve chart.
        
        Args:
            results_df: DataFrame with backtest results
            strategy_name: Strategy name
            symbol: Cryptocurrency symbol
            timeframe: Timeframe of the data
            
        Returns:
            Path to the saved chart
        """
        try:
            # Create figure
            plt.figure(figsize=(12, 8))
            
            # Plot equity curve
            plt.subplot(2, 1, 1)
            plt.plot(results_df['equity'], label='Equity')
            plt.title(f"Equity Curve - {strategy_name} on {symbol} ({timeframe})")
            plt.xlabel('Time')
            plt.ylabel('Equity ($)')
            plt.grid(True)
            plt.legend()
            
            # Plot drawdown
            plt.subplot(2, 1, 2)
            plt.plot(results_df['drawdown'] * 100, color='red', label='Drawdown')
            plt.fill_between(results_df.index, results_df['drawdown'] * 100, 0, color='red', alpha=0.3)
            plt.title('Drawdown')
            plt.xlabel('Time')
            plt.ylabel('Drawdown (%)')
            plt.grid(True)
            plt.legend()
            
            # Adjust layout
            plt.tight_layout()
            
            # Save chart
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            chart_path = f"{self.output_dir}/{symbol.replace('/', '_')}_{timeframe}_{strategy_name}_{timestamp}_equity.png"
            plt.savefig(chart_path)
            plt.close()
            
            return chart_path
            
        except Exception as e:
            self.logger.error(f"Error generating equity curve: {e}", exc_info=True)
            return None
    
    def _save_performance_report(self, report, strategy_name, symbol, timeframe):
        """
        Save performance report to file.
        
        Args:
            report: Dict with performance report
            strategy_name: Strategy name
            symbol: Cryptocurrency symbol
            timeframe: Timeframe of the data
            
        Returns:
            Path to the saved report
        """
        try:
            # Generate timestamp
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            
            # Generate filename
            filename = f"{self.output_dir}/{symbol.replace('/', '_')}_{timeframe}_{strategy_name}_{timestamp}_report.json"
            
            # Save report
            with open(filename, 'w') as f:
                json.dump(report, f, indent=4)
            
            self.logger.info(f"Saved performance report to {filename}")
            
            return filename
            
        except Exception as e:
            self.logger.error(f"Error saving performance report: {e}", exc_info=True)
            return None
    
    def compare_strategies(self, strategies, symbol, start_date, end_date, 
                         timeframe='1Min', initial_capital=10000.0,
                         commission=0.001, slippage=0.0005):
        """
        Compare multiple trading strategies.
        
        Args:
            strategies: List of trading strategy instances
            symbol: Cryptocurrency symbol
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            timeframe: Timeframe of the data
            initial_capital: Initial capital for the backtest
            commission: Commission rate per trade
            slippage: Slippage rate per trade
            
        Returns:
            Dict with comparison results
        """
        try:
            self.logger.info(f"Comparing {len(strategies)} strategies on {symbol}")
            
            # Run backtest for each strategy
            results = {}
            
            for strategy in strategies:
                strategy_name = strategy.name
                self.logger.info(f"Evaluating strategy: {strategy_name}")
                
                # Run evaluation
                evaluation_results = self.run_strategy_evaluation(
                    strategy, symbol, start_date, end_date, timeframe,
                    initial_capital, commission, slippage
                )
                
                if evaluation_results:
                    results[strategy_name] = evaluation_results
            
            # Compare strategies
            comparison = self._compare_strategies(results)
            
            # Generate comparison chart
            chart_path = self._generate_comparison_chart(results, symbol, timeframe)
            if chart_path:
                comparison['comparison_chart'] = chart_path
            
            # Save comparison results
            comparison_path = self._save_comparison_results(comparison, symbol, timeframe)
            
            return {
                'comparison': comparison,
                'comparison_path': comparison_path,
                'strategy_results': results
            }
            
        except Exception as e:
            self.logger.error(f"Error comparing strategies: {e}", exc_info=True)
            return {}
    
    def _compare_strategies(self, results):
        """
        Compare performance metrics for multiple strategies.
        
        Args:
            results: Dict with evaluation results for each strategy
            
        Returns:
            Dict with comparison results
        """
        try:
            # Initialize comparison
            comparison = {
                'strategies': list(results.keys()),
                'metrics': {}
            }
            
            # Define metrics to compare
            metrics = [
                'total_return', 'annual_return', 'max_drawdown', 'sharpe_ratio',
                'sortino_ratio', 'volatility', 'num_trades', 'win_rate',
                'profit_factor'
            ]
            
            # Compare each metric
            for metric in metrics:
                comparison['metrics'][metric] = {}
                
                for strategy_name, evaluation_results in results.items():
                    backtest_results = evaluation_results.get('backtest_results', {})
                    performance = backtest_results.get('performance', {})
                    comparison['metrics'][metric][strategy_name] = performance.get(metric, 0)
            
            # Determine best strategy for each metric
            comparison['best_strategy'] = {}
            
            for metric in metrics:
                if metric in ['max_drawdown', 'volatility']:
                    # Lower is better
                    best_strategy = min(
                        comparison['metrics'][metric].items(),
                        key=lambda x: x[1]
                    )[0]
                else:
                    # Higher is better
                    best_strategy = max(
                        comparison['metrics'][metric].items(),
                        key=lambda x: x[1]
                    )[0]
                
                comparison['best_strategy'][metric] = best_strategy
            
            # Determine overall best strategy
            # Simple scoring: count how many times each strategy is the best
            scores = {}
            for strategy_name in comparison['strategies']:
                scores[strategy_name] = sum(
                    1 for metric, best in comparison['best_strategy'].items()
                    if best == strategy_name
                )
            
            comparison['overall_best_strategy'] = max(
                scores.items(),
                key=lambda x: x[1]
            )[0]
            
            self.logger.info(f"Overall best strategy: {comparison['overall_best_strategy']}")
            
            return comparison
            
        except Exception as e:
            self.logger.error(f"Error comparing strategies: {e}", exc_info=True)
            return {}
    
    def _generate_comparison_chart(self, results, symbol, timeframe):
        """
        Generate a comparison chart for multiple strategies.
        
        Args:
            results: Dict with evaluation results for each strategy
            symbol: Cryptocurrency symbol
            timeframe: Timeframe of the data
            
        Returns:
            Path to the saved chart
        """
        try:
            # Create figure
            plt.figure(figsize=(12, 8))
            
            # Plot equity curves
            for strategy_name, evaluation_results in results.items():
                backtest_results = evaluation_results.get('backtest_results', {})
                results_df = backtest_results.get('results', {}).get('results_df')
                
                if results_df is not None and not results_df.empty:
                    plt.plot(results_df['equity'], label=strategy_name)
            
            # Add labels and legend
            plt.title(f"Strategy Comparison - {symbol} ({timeframe})")
            plt.xlabel('Time')
            plt.ylabel('Equity ($)')
            plt.grid(True)
            plt.legend()
            
            # Save chart
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            chart_path = f"{self.output_dir}/{symbol.replace('/', '_')}_{timeframe}_comparison_{timestamp}.png"
            plt.savefig(chart_path)
            plt.close()
            
            return chart_path
            
        except Exception as e:
            self.logger.error(f"Error generating comparison chart: {e}", exc_info=True)
            return None
    
    def _save_comparison_results(self, comparison, symbol, timeframe):
        """
        Save strategy comparison results to file.
        
        Args:
            comparison: Dict with comparison results
            symbol: Cryptocurrency symbol
            timeframe: Timeframe of the data
            
        Returns:
            Path to the saved file
        """
        try:
            # Generate timestamp
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            
            # Generate filename
            filename = f"{self.output_dir}/{symbol.replace('/', '_')}_{timeframe}_comparison_{timestamp}.json"
            
            # Save comparison results
            with open(filename, 'w') as f:
                json.dump(comparison, f, indent=4)
            
            self.logger.info(f"Saved comparison results to {filename}")
            
            return filename
            
        except Exception as e:
            self.logger.error(f"Error saving comparison results: {e}", exc_info=True)
            return None
    
    def optimize_strategy_parameters(self, strategy_class, parameter_grid, symbol, 
                                   start_date, end_date, timeframe='1Min',
                                   initial_capital=10000.0, commission=0.001, 
                                   slippage=0.0005, optimization_metric='sharpe_ratio'):
        """
        Optimize strategy parameters using grid search.
        
        Args:
            strategy_class: Trading strategy class
            parameter_grid: Dict with parameter names and values to test
            symbol: Cryptocurrency symbol
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            timeframe: Timeframe of the data
            initial_capital: Initial capital for the backtest
            commission: Commission rate per trade
            slippage: Slippage rate per trade
            optimization_metric: Metric to optimize
            
        Returns:
            Dict with optimization results
        """
        try:
            self.logger.info(f"Optimizing parameters for {strategy_class.__name__} on {symbol}")
            
            # Generate parameter combinations
            parameter_combinations = self._generate_parameter_combinations(parameter_grid)
            
            self.logger.info(f"Testing {len(parameter_combinations)} parameter combinations")
            
            # Run backtest for each parameter combination
            results = []
            
            for params in parameter_combinations:
                # Create strategy instance with parameters
                strategy = strategy_class(**params)
                
                # Run backtest
                backtest_results = self.backtest_engine.run_backtest(
                    strategy, symbol, start_date, end_date, timeframe,
                    initial_capital, commission, slippage
                )
                
                if backtest_results:
                    # Extract performance metrics
                    performance = backtest_results.get('performance', {})
                    
                    # Add parameters and performance to results
                    result = {
                        'parameters': params,
                        'performance': performance
                    }
                    
                    results.append(result)
            
            # Find best parameter combination
            if optimization_metric in ['max_drawdown', 'volatility']:
                # Lower is better
                best_result = min(
                    results,
                    key=lambda x: x['performance'].get(optimization_metric, float('inf'))
                )
            else:
                # Higher is better
                best_result = max(
                    results,
                    key=lambda x: x['performance'].get(optimization_metric, 0)
                )
            
            # Create strategy with best parameters
            best_strategy = strategy_class(**best_result['parameters'])
            
            # Run backtest with best parameters
            best_backtest_results = self.backtest_engine.run_backtest(
                best_strategy, symbol, start_date, end_date, timeframe,
                initial_capital, commission, slippage
            )
            
            # Generate optimization report
            optimization_report = {
                'strategy_class': strategy_class.__name__,
                'symbol': symbol,
                'timeframe': timeframe,
                'optimization_metric': optimization_metric,
                'parameter_grid': parameter_grid,
                'num_combinations': len(parameter_combinations),
                'best_parameters': best_result['parameters'],
                'best_performance': best_result['performance'],
                'all_results': results
            }
            
            # Save optimization report
            report_path = self._save_optimization_report(optimization_report, strategy_class.__name__, symbol, timeframe)
            
            # Generate parameter heatmap if possible
            if len(parameter_grid) == 2:
                heatmap_path = self._generate_parameter_heatmap(
                    results, list(parameter_grid.keys()), optimization_metric,
                    strategy_class.__name__, symbol, timeframe
                )
                if heatmap_path:
                    optimization_report['heatmap_path'] = heatmap_path
            
            return {
                'optimization_report': optimization_report,
                'report_path': report_path,
                'best_strategy': best_strategy,
                'best_backtest_results': best_backtest_results
            }
            
        except Exception as e:
            self.logger.error(f"Error optimizing strategy parameters: {e}", exc_info=True)
            return {}
    
    def _generate_parameter_combinations(self, parameter_grid):
        """
        Generate all combinations of parameters from a grid.
        
        Args:
            parameter_grid: Dict with parameter names and values to test
            
        Returns:
            List of parameter dictionaries
        """
        try:
            # Get parameter names and values
            param_names = list(parameter_grid.keys())
            param_values = list(parameter_grid.values())
            
            # Generate all combinations
            combinations = []
            
            # Recursive function to generate combinations
            def generate_combinations(index, current_params):
                if index == len(param_names):
                    combinations.append(current_params.copy())
                    return
                
                param_name = param_names[index]
                for value in param_values[index]:
                    current_params[param_name] = value
                    generate_combinations(index + 1, current_params)
            
            # Start recursive generation
            generate_combinations(0, {})
            
            return combinations
            
        except Exception as e:
            self.logger.error(f"Error generating parameter combinations: {e}", exc_info=True)
            return []
    
    def _save_optimization_report(self, report, strategy_name, symbol, timeframe):
        """
        Save optimization report to file.
        
        Args:
            report: Dict with optimization report
            strategy_name: Strategy name
            symbol: Cryptocurrency symbol
            timeframe: Timeframe of the data
            
        Returns:
            Path to the saved report
        """
        try:
            # Generate timestamp
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            
            # Generate filename
            filename = f"{self.output_dir}/{symbol.replace('/', '_')}_{timeframe}_{strategy_name}_optimization_{timestamp}.json"
            
            # Save report
            with open(filename, 'w') as f:
                # Remove 'all_results' to keep file size manageable
                report_copy = report.copy()
                report_copy['all_results'] = f"{len(report['all_results'])} results (removed from file to reduce size)"
                json.dump(report_copy, f, indent=4)
            
            self.logger.info(f"Saved optimization report to {filename}")
            
            return filename
            
        except Exception as e:
            self.logger.error(f"Error saving optimization report: {e}", exc_info=True)
            return None
    
    def _generate_parameter_heatmap(self, results, param_names, metric, strategy_name, symbol, timeframe):
        """
        Generate a heatmap of parameter combinations.
        
        Args:
            results: List of result dictionaries
            param_names: List of parameter names
            metric: Performance metric to visualize
            strategy_name: Strategy name
            symbol: Cryptocurrency symbol
            timeframe: Timeframe of the data
            
        Returns:
            Path to the saved heatmap
        """
        try:
            if len(param_names) != 2:
                return None
            
            # Extract parameter values
            param1_values = sorted(list(set(result['parameters'][param_names[0]] for result in results)))
            param2_values = sorted(list(set(result['parameters'][param_names[1]] for result in results)))
            
            # Create heatmap data
            heatmap_data = np.zeros((len(param1_values), len(param2_values)))
            
            for result in results:
                param1_idx = param1_values.index(result['parameters'][param_names[0]])
                param2_idx = param2_values.index(result['parameters'][param_names[1]])
                heatmap_data[param1_idx, param2_idx] = result['performance'].get(metric, 0)
            
            # Create figure
            plt.figure(figsize=(12, 10))
            
            # Plot heatmap
            plt.imshow(heatmap_data, cmap='viridis')
            plt.colorbar(label=metric)
            
            # Add labels
            plt.title(f"Parameter Optimization - {strategy_name} on {symbol} ({timeframe})")
            plt.xlabel(param_names[1])
            plt.ylabel(param_names[0])
            
            # Add ticks
            plt.xticks(range(len(param2_values)), param2_values)
            plt.yticks(range(len(param1_values)), param1_values)
            
            # Add values to cells
            for i in range(len(param1_values)):
                for j in range(len(param2_values)):
                    plt.text(j, i, f"{heatmap_data[i, j]:.2f}", 
                             ha="center", va="center", color="w")
            
            # Save heatmap
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            heatmap_path = f"{self.output_dir}/{symbol.replace('/', '_')}_{timeframe}_{strategy_name}_heatmap_{timestamp}.png"
            plt.savefig(heatmap_path)
            plt.close()
            
            return heatmap_path
            
        except Exception as e:
            self.logger.error(f"Error generating parameter heatmap: {e}", exc_info=True)
            return None

# Example usage
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Create performance evaluator
    evaluator = PerformanceEvaluator()
    
    # Create strategies
    spike_strategy = SpikeDetectionStrategy(threshold=0.7, holding_period=5)
    ma_strategy = MovingAverageCrossoverStrategy(fast_period=20, slow_period=50)
    advanced_strategy = AdvancedTradingStrategy(risk_per_trade=0.02, max_portfolio_risk=0.1)
    adaptive_strategy = AdaptiveTradingStrategy(base_risk_per_trade=0.02)
    
    # Define backtest parameters
    symbol = "BTC/USD"
    start_date = "2023-01-01"
    end_date = "2023-01-31"
    timeframe = "1H"
    
    # Run strategy evaluation
    evaluation_results = evaluator.run_strategy_evaluation(
        advanced_strategy, symbol, start_date, end_date, timeframe
    )
    
    # Compare strategies
    strategies = [spike_strategy, ma_strategy, advanced_strategy, adaptive_strategy]
    comparison_results = evaluator.compare_strategies(
        strategies, symbol, start_date, end_date, timeframe
    )
    
    # Optimize strategy parameters
    parameter_grid = {
        'threshold': [0.6, 0.7, 0.8],
        'holding_period': [3, 5, 7]
    }
    
    optimization_results = evaluator.optimize_strategy_parameters(
        SpikeDetectionStrategy, parameter_grid, symbol, start_date, end_date, timeframe
    )
    
    # Print results
    if evaluation_results:
        report = evaluation_results.get('report', {})
        print(f"Strategy evaluation results:")
        print(f"Total return: {report.get('metrics', {}).get('returns', {}).get('total_return', '0%')}")
        print(f"Sharpe ratio: {report.get('metrics', {}).get('risk', {}).get('sharpe_ratio', '0.0')}")
    
    if comparison_results:
        comparison = comparison_results.get('comparison', {})
        print(f"\nStrategy comparison results:")
        print(f"Overall best strategy: {comparison.get('overall_best_strategy', '')}")
    
    if optimization_results:
        optimization_report = optimization_results.get('optimization_report', {})
        print(f"\nStrategy optimization results:")
        print(f"Best parameters: {optimization_report.get('best_parameters', {})}")
        print(f"Best performance: {optimization_report.get('best_performance', {}).get(optimization_report.get('optimization_metric', ''), 0)}")
