import os
import logging
import asyncio
from alpaca.data import CryptoHistoricalDataClient
from alpaca.data.timeframe import TimeFrame
from alpaca.data.requests import CryptoBarsRequest
from datetime import datetime, timedelta

class AlpacaDataClient:
    """
    Client for fetching historical cryptocurrency data from Alpaca Markets.
    """
    
    def __init__(self, api_key, api_secret):
        """
        Initialize the AlpacaDataClient.
        
        Args:
            api_key (str): Alpaca API key
            api_secret (str): Alpaca API secret
        """
        self.logger = logging.getLogger("alpaca_data_client")
        self.client = CryptoHistoricalDataClient(api_key, api_secret)
        
        # Create data directory if it doesn't exist
        os.makedirs("data/historical", exist_ok=True)
        
        self.logger.info("AlpacaDataClient initialized")
    
    async def get_historical_bars(self, symbols, start_date, end_date=None, timeframe=TimeFrame.Minute):
        """
        Fetch historical bar data for specified symbols.
        
        Args:
            symbols (list): List of cryptocurrency symbols
            start_date (datetime): Start date for historical data
            end_date (datetime, optional): End date for historical data (defaults to now)
            timeframe (TimeFrame): Timeframe for the bars
            
        Returns:
            dict: Historical bar data
        """
        try:
            if end_date is None:
                end_date = datetime.now()
            
            self.logger.info(f"Fetching historical bars for {symbols} from {start_date} to {end_date}")
            
            request_params = CryptoBarsRequest(
                symbol_or_symbols=symbols,
                timeframe=timeframe,
                start=start_date,
                end=end_date
            )
            
            bars = self.client.get_crypto_bars(request_params)
            
            self.logger.info(f"Fetched {len(bars)} bars")
            return bars
            
        except Exception as e:
            self.logger.error(f"Error fetching historical bars: {e}", exc_info=True)
            return None
    
    async def download_historical_data(self, symbols, days_back=30, timeframe=TimeFrame.Minute):
        """
        Download and save historical data for specified symbols.
        
        Args:
            symbols (list): List of cryptocurrency symbols
            days_back (int): Number of days of historical data to fetch
            timeframe (TimeFrame): Timeframe for the bars
            
        Returns:
            bool: Success status
        """
        try:
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days_back)
            
            self.logger.info(f"Downloading {days_back} days of historical data for {symbols}")
            
            bars = await self.get_historical_bars(symbols, start_date, end_date, timeframe)
            
            if bars is None:
                return False
            
            # Save data for each symbol
            for symbol in symbols:
                if symbol in bars:
                    symbol_bars = bars[symbol]
                    filename = f"data/historical/{symbol.replace('/', '_')}_{timeframe.value}_{start_date.strftime('%Y%m%d')}_to_{end_date.strftime('%Y%m%d')}.csv"
                    
                    # Convert to DataFrame and save to CSV
                    df = symbol_bars.df
                    df.to_csv(filename)
                    
                    self.logger.info(f"Saved historical data for {symbol} to {filename}")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error downloading historical data: {e}", exc_info=True)
            return False

# Example usage
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Replace with your Alpaca API credentials
    API_KEY = "your_api_key"
    API_SECRET = "your_api_secret"
    
    # List of symbols to fetch
    SYMBOLS = ["BTC/USD", "ETH/USD"]
    
    # Create data client
    data_client = AlpacaDataClient(API_KEY, API_SECRET)
    
    # Run the download
    asyncio.run(data_client.download_historical_data(SYMBOLS, days_back=7))
