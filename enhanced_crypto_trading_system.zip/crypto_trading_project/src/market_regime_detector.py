import logging
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from statsmodels.tsa.stattools import adfuller
from scipy import stats

class MarketRegimeDetector:
    """
    Enhanced market regime detection system that identifies different market conditions
    using multiple methods and indicators.
    """
    
    def __init__(self):
        """Initialize the MarketRegimeDetector."""
        self.logger = logging.getLogger("market_regime_detector")
        self.regime_history = {}
        
    def detect_regime(self, df, symbol, methods=None):
        """
        Detect the current market regime using multiple methods.
        
        Args:
            df: DataFrame with OHLCV data
            symbol: Symbol to detect regime for
            methods: List of methods to use for detection (default: all)
            
        Returns:
            dict: Market regime information
        """
        if df is None or df.empty:
            self.logger.warning(f"Empty data provided for {symbol}")
            return {"regime": "unknown", "confidence": 0.0, "details": {}}
        
        # Default to all methods if none specified
        if methods is None:
            methods = [
                "trend_analysis", 
                "volatility_analysis", 
                "statistical_analysis",
                "pattern_recognition",
                "volume_analysis",
                "clustering"
            ]
        
        results = {}
        
        # Apply each method
        for method in methods:
            if method == "trend_analysis":
                results[method] = self._detect_trend(df)
            elif method == "volatility_analysis":
                results[method] = self._detect_volatility_regime(df)
            elif method == "statistical_analysis":
                results[method] = self._detect_statistical_regime(df)
            elif method == "pattern_recognition":
                results[method] = self._detect_patterns(df)
            elif method == "volume_analysis":
                results[method] = self._detect_volume_regime(df)
            elif method == "clustering":
                results[method] = self._detect_regime_clustering(df)
        
        # Combine results from all methods
        combined_result = self._combine_regime_results(results)
        
        # Store history
        if symbol not in self.regime_history:
            self.regime_history[symbol] = []
        
        self.regime_history[symbol].append({
            "timestamp": df.index[-1],
            "regime": combined_result["regime"],
            "confidence": combined_result["confidence"],
            "details": combined_result["details"]
        })
        
        # Limit history size
        if len(self.regime_history[symbol]) > 100:
            self.regime_history[symbol] = self.regime_history[symbol][-100:]
        
        return combined_result
    
    def _detect_trend(self, df):
        """
        Detect market trend using multiple indicators.
        
        Args:
            df: DataFrame with OHLCV data
            
        Returns:
            dict: Trend analysis results
        """
        try:
            # Calculate indicators
            df = df.copy()
            
            # Moving averages
            df['sma20'] = df['close'].rolling(window=20).mean()
            df['sma50'] = df['close'].rolling(window=50).mean()
            df['sma200'] = df['close'].rolling(window=200).mean()
            
            # ADX (Average Directional Index) for trend strength
            df['tr1'] = abs(df['high'] - df['low'])
            df['tr2'] = abs(df['high'] - df['close'].shift(1))
            df['tr3'] = abs(df['low'] - df['close'].shift(1))
            df['tr'] = df[['tr1', 'tr2', 'tr3']].max(axis=1)
            df['plus_dm'] = np.where((df['high'] - df['high'].shift(1)) > (df['low'].shift(1) - df['low']),
                                    np.maximum(df['high'] - df['high'].shift(1), 0), 0)
            df['minus_dm'] = np.where((df['low'].shift(1) - df['low']) > (df['high'] - df['high'].shift(1)),
                                     np.maximum(df['low'].shift(1) - df['low'], 0), 0)
            
            # Calculate smoothed values
            period = 14
            df['tr14'] = df['tr'].rolling(window=period).sum()
            df['plus_di14'] = 100 * (df['plus_dm'].rolling(window=period).sum() / df['tr14'])
            df['minus_di14'] = 100 * (df['minus_dm'].rolling(window=period).sum() / df['tr14'])
            df['dx'] = 100 * abs(df['plus_di14'] - df['minus_di14']) / (df['plus_di14'] + df['minus_di14'])
            df['adx'] = df['dx'].rolling(window=period).mean()
            
            # Linear regression slope
            df['price_change'] = df['close'].pct_change()
            df['slope20'] = df['close'].rolling(window=20).apply(
                lambda x: stats.linregress(np.arange(len(x)), x)[0] / x.mean(), raw=True)
            
            # Get latest values
            latest = df.iloc[-1]
            
            # Determine trend based on moving averages
            ma_trend = 0
            if latest['close'] > latest['sma20'] > latest['sma50']:
                ma_trend += 1
            if latest['close'] < latest['sma20'] < latest['sma50']:
                ma_trend -= 1
            if latest['sma20'] > latest['sma50'] > latest['sma200']:
                ma_trend += 1
            if latest['sma20'] < latest['sma50'] < latest['sma200']:
                ma_trend -= 1
                
            # Determine trend strength based on ADX
            adx_value = latest['adx']
            adx_trend = 0
            if adx_value > 25:  # Strong trend
                if latest['plus_di14'] > latest['minus_di14']:
                    adx_trend = 1
                else:
                    adx_trend = -1
            
            # Determine trend based on slope
            slope_trend = 0
            if latest['slope20'] > 0.001:
                slope_trend = 1
            elif latest['slope20'] < -0.001:
                slope_trend = -1
            
            # Combine trend indicators
            trend_score = ma_trend + adx_trend + slope_trend
            
            if trend_score >= 2:
                trend = "uptrend"
                strength = min(abs(trend_score) / 3, 1.0)
            elif trend_score <= -2:
                trend = "downtrend"
                strength = min(abs(trend_score) / 3, 1.0)
            else:
                trend = "sideways"
                strength = 1.0 - min(abs(trend_score) / 3, 1.0)
            
            return {
                "regime": trend,
                "confidence": strength,
                "details": {
                    "adx": adx_value,
                    "ma_trend": ma_trend,
                    "adx_trend": adx_trend,
                    "slope_trend": slope_trend,
                    "trend_score": trend_score
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error in trend detection: {e}", exc_info=True)
            return {"regime": "unknown", "confidence": 0.0, "details": {}}
    
    def _detect_volatility_regime(self, df):
        """
        Detect volatility regime.
        
        Args:
            df: DataFrame with OHLCV data
            
        Returns:
            dict: Volatility regime results
        """
        try:
            # Calculate indicators
            df = df.copy()
            
            # Calculate volatility metrics
            df['returns'] = df['close'].pct_change()
            df['volatility'] = df['returns'].rolling(window=20).std() * np.sqrt(252)  # Annualized
            
            # ATR (Average True Range)
            df['tr1'] = abs(df['high'] - df['low'])
            df['tr2'] = abs(df['high'] - df['close'].shift(1))
            df['tr3'] = abs(df['low'] - df['close'].shift(1))
            df['tr'] = df[['tr1', 'tr2', 'tr3']].max(axis=1)
            df['atr14'] = df['tr'].rolling(window=14).mean()
            df['atr_pct'] = df['atr14'] / df['close']
            
            # Bollinger Bands width
            df['sma20'] = df['close'].rolling(window=20).mean()
            df['stddev'] = df['close'].rolling(window=20).std()
            df['bb_width'] = (df['sma20'] + 2 * df['stddev'] - (df['sma20'] - 2 * df['stddev'])) / df['sma20']
            
            # Get latest values
            latest = df.iloc[-1]
            
            # Historical volatility percentiles
            vol_percentile = stats.percentileofscore(
                df['volatility'].dropna(), latest['volatility']) / 100
            atr_percentile = stats.percentileofscore(
                df['atr_pct'].dropna(), latest['atr_pct']) / 100
            bb_percentile = stats.percentileofscore(
                df['bb_width'].dropna(), latest['bb_width']) / 100
            
            # Combine volatility metrics
            vol_score = (vol_percentile + atr_percentile + bb_percentile) / 3
            
            if vol_score > 0.7:
                regime = "high_volatility"
                confidence = (vol_score - 0.7) / 0.3  # Scale 0.7-1.0 to 0-1
            elif vol_score < 0.3:
                regime = "low_volatility"
                confidence = (0.3 - vol_score) / 0.3  # Scale 0-0.3 to 0-1
            else:
                regime = "normal_volatility"
                confidence = 1.0 - abs(vol_score - 0.5) / 0.2  # Highest at 0.5
            
            return {
                "regime": regime,
                "confidence": confidence,
                "details": {
                    "volatility": latest['volatility'],
                    "atr_pct": latest['atr_pct'],
                    "bb_width": latest['bb_width'],
                    "vol_percentile": vol_percentile,
                    "atr_percentile": atr_percentile,
                    "bb_percentile": bb_percentile,
                    "vol_score": vol_score
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error in volatility regime detection: {e}", exc_info=True)
            return {"regime": "unknown", "confidence": 0.0, "details": {}}
    
    def _detect_statistical_regime(self, df):
        """
        Detect statistical properties of the market.
        
        Args:
            df: DataFrame with OHLCV data
            
        Returns:
            dict: Statistical regime results
        """
        try:
            # Calculate returns
            df = df.copy()
            df['returns'] = df['close'].pct_change()
            
            # Get recent returns (last 30 periods)
            recent_returns = df['returns'].dropna().tail(30)
            
            if len(recent_returns) < 30:
                return {"regime": "unknown", "confidence": 0.0, "details": {}}
            
            # Test for stationarity (Augmented Dickey-Fuller test)
            adf_result = adfuller(df['close'].dropna().tail(60))
            is_stationary = adf_result[1] < 0.05  # p-value < 0.05 means stationary
            
            # Test for normality (Shapiro-Wilk test)
            _, normality_pvalue = stats.shapiro(recent_returns)
            is_normal = normality_pvalue > 0.05  # p-value > 0.05 means normal
            
            # Calculate skewness and kurtosis
            skewness = stats.skew(recent_returns)
            kurtosis = stats.kurtosis(recent_returns)
            
            # Determine regime based on statistical properties
            if is_stationary:
                if abs(skewness) < 0.5 and abs(kurtosis) < 1:
                    regime = "mean_reverting_normal"
                    confidence = 0.7 + (0.3 * (1 - abs(skewness) / 0.5))
                else:
                    regime = "mean_reverting_nonnormal"
                    confidence = 0.6 + (0.4 * (1 - min(abs(skewness) / 2, 1)))
            else:
                if abs(skewness) > 1 or kurtosis > 3:
                    regime = "trending_fat_tails"
                    confidence = 0.6 + (0.4 * min(max(abs(skewness) / 2, kurtosis / 6), 1))
                else:
                    regime = "random_walk"
                    confidence = 0.5 + (0.5 * (1 - normality_pvalue))
            
            return {
                "regime": regime,
                "confidence": confidence,
                "details": {
                    "is_stationary": is_stationary,
                    "adf_pvalue": adf_result[1],
                    "is_normal": is_normal,
                    "normality_pvalue": normality_pvalue,
                    "skewness": skewness,
                    "kurtosis": kurtosis
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error in statistical regime detection: {e}", exc_info=True)
            return {"regime": "unknown", "confidence": 0.0, "details": {}}
    
    def _detect_patterns(self, df):
        """
        Detect chart patterns in the market.
        
        Args:
            df: DataFrame with OHLCV data
            
        Returns:
            dict: Pattern recognition results
        """
        try:
            # Calculate indicators
            df = df.copy()
            
            # Detect support and resistance levels
            window = 20
            df['rolling_high'] = df['high'].rolling(window=window).max()
            df['rolling_low'] = df['low'].rolling(window=window).min()
            
            # Detect if price is near support or resistance
            latest = df.iloc[-1]
            price = latest['close']
            
            # Calculate distance to support/resistance as percentage
            support_distance = (price - latest['rolling_low']) / price
            resistance_distance = (latest['rolling_high'] - price) / price
            
            # Detect breakouts
            breakout_threshold = 0.02  # 2%
            prev_resistance = df['rolling_high'].shift(1).iloc[-1]
            prev_support = df['rolling_low'].shift(1).iloc[-1]
            
            resistance_breakout = price > prev_resistance * (1 + breakout_threshold)
            support_breakdown = price < prev_support * (1 - breakout_threshold)
            
            # Detect consolidation (narrowing Bollinger Bands)
            df['sma20'] = df['close'].rolling(window=20).mean()
            df['stddev'] = df['close'].rolling(window=20).std()
            df['bb_width'] = (df['sma20'] + 2 * df['stddev'] - (df['sma20'] - 2 * df['stddev'])) / df['sma20']
            
            # Check if BB width is narrowing
            bb_width_change = df['bb_width'].pct_change(periods=5).iloc[-1]
            is_consolidating = bb_width_change < -0.1  # BB width decreased by 10%
            
            # Determine pattern-based regime
            if resistance_breakout:
                regime = "breakout"
                confidence = 0.7 + (0.3 * min(price / prev_resistance - 1, 0.1) / 0.1)
            elif support_breakdown:
                regime = "breakdown"
                confidence = 0.7 + (0.3 * min(1 - price / prev_support, 0.1) / 0.1)
            elif is_consolidating:
                regime = "consolidation"
                confidence = 0.6 + (0.4 * min(abs(bb_width_change) / 0.2, 1))
            elif support_distance < 0.03:  # Within 3% of support
                regime = "near_support"
                confidence = 0.6 + (0.4 * (1 - support_distance / 0.03))
            elif resistance_distance < 0.03:  # Within 3% of resistance
                regime = "near_resistance"
                confidence = 0.6 + (0.4 * (1 - resistance_distance / 0.03))
            else:
                regime = "range_bound"
                confidence = 0.5
            
            return {
                "regime": regime,
                "confidence": confidence,
                "details": {
                    "support_distance": support_distance,
                    "resistance_distance": resistance_distance,
                    "resistance_breakout": resistance_breakout,
                    "support_breakdown": support_breakdown,
                    "is_consolidating": is_consolidating,
                    "bb_width_change": bb_width_change
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error in pattern recognition: {e}", exc_info=True)
            return {"regime": "unknown", "confidence": 0.0, "details": {}}
    
    def _detect_volume_regime(self, df):
        """
        Detect volume-based market regime.
        
        Args:
            df: DataFrame with OHLCV data
            
        Returns:
            dict: Volume regime results
        """
        try:
            # Calculate indicators
            df = df.copy()
            
            # Volume metrics
            df['volume_sma20'] = df['volume'].rolling(window=20).mean()
            df['volume_ratio'] = df['volume'] / df['volume_sma20']
            
            # Volume and price relationship
            df['returns'] = df['close'].pct_change()
            df['abs_returns'] = df['returns'].abs()
            
            # Calculate volume-price correlation (last 20 periods)
            corr_window = 20
            df['vol_price_corr'] = df['volume'].rolling(window=corr_window).corr(df['abs_returns'])
            
            # Get latest values
            latest = df.iloc[-1]
            
            # Determine volume regime
            vol_ratio = latest['volume_ratio']
            vol_price_corr = latest['vol_price_corr']
            
            if vol_ratio > 2.0:  # Volume spike
                if latest['returns'] > 0:
                    regime = "high_volume_bullish"
                    confidence = 0.7 + (0.3 * min(vol_ratio / 5, 1))
                else:
                    regime = "high_volume_bearish"
                    confidence = 0.7 + (0.3 * min(vol_ratio / 5, 1))
            elif vol_ratio < 0.5:  # Low volume
                regime = "low_volume"
                confidence = 0.6 + (0.4 * (1 - vol_ratio / 0.5))
            elif vol_price_corr > 0.7:  # Strong volume-price correlation
                regime = "efficient_market"
                confidence = 0.6 + (0.4 * (vol_price_corr - 0.7) / 0.3)
            elif vol_price_corr < 0.3:  # Weak volume-price correlation
                regime = "inefficient_market"
                confidence = 0.6 + (0.4 * (0.3 - vol_price_corr) / 0.3)
            else:
                regime = "normal_volume"
                confidence = 0.5
            
            return {
                "regime": regime,
                "confidence": confidence,
                "details": {
                    "volume_ratio": vol_ratio,
                    "vol_price_corr": vol_price_corr
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error in volume regime detection: {e}", exc_info=True)
            return {"regime": "unknown", "confidence": 0.0, "details": {}}
    
    def _detect_regime_clustering(self, df):
        """
        Detect market regime using unsupervised clustering.
        
        Args:
            df: DataFrame with OHLCV data
            
        Returns:
            dict: Clustering regime results
        """
        try:
            # Calculate features for clustering
            df = df.copy()
            
            # Calculate returns and volatility
            df['returns'] = df['close'].pct_change()
            df['volatility'] = df['returns'].rolling(window=20).std()
            
            # Calculate volume features
            df['volume_sma20'] = df['volume'].rolling(window=20).mean()
            df['volume_ratio'] = df['volume'] / df['volume_sma20']
            
            # Calculate trend features
            df['sma20'] = df['close'].rolling(window=20).mean()
            df['sma50'] = df['close'].rolling(window=50).mean()
            df['trend_indicator'] = (df['sma20'] / df['sma50']) - 1
            
            # Calculate momentum
            df['momentum'] = df['close'].pct_change(periods=10)
            
            # Prepare features for clustering
            features = df[['returns', 'volatility', 'volume_ratio', 'trend_indicator', 'momentum']].dropna()
            
            if len(features) < 50:  # Need enough data for meaningful clustering
                return {"regime": "unknown", "confidence": 0.0, "details": {}}
            
            # Standardize features
            scaler = StandardScaler()
            scaled_features = scaler.fit_transform(features)
            
            # Apply K-means clustering (3 clusters)
            kmeans = KMeans(n_clusters=3, random_state=42)
            clusters = kmeans.fit_predict(scaled_features)
            
            # Analyze cluster characteristics
            cluster_df = features.copy()
            cluster_df['cluster'] = clusters
            
            cluster_stats = {}
            for cluster in range(3):
                cluster_data = cluster_df[cluster_df['cluster'] == cluster]
                cluster_stats[cluster] = {
                    'returns_mean': cluster_data['returns'].mean(),
                    'volatility_mean': cluster_data['volatility'].mean(),
                    'volume_ratio_mean': cluster_data['volume_ratio'].mean(),
                    'trend_indicator_mean': cluster_data['trend_indicator'].mean(),
                    'momentum_mean': cluster_data['momentum'].mean(),
                    'size': len(cluster_data)
                }
            
            # Determine cluster characteristics
            bull_cluster = None
            bear_cluster = None
            neutral_cluster = None
            
            # Find bull and bear clusters based on returns and momentum
            clusters_by_returns = sorted(range(3), key=lambda i: cluster_stats[i]['returns_mean'])
            bear_cluster = clusters_by_returns[0]
            neutral_cluster = clusters_by_returns[1]
            bull_cluster = clusters_by_returns[2]
            
            # Get the latest data point
            latest_features = scaled_features[-1].reshape(1, -1)
            latest_cluster = kmeans.predict(latest_features)[0]
            
            # Calculate distance to cluster centroid (for confidence)
            centroid_distance = np.linalg.norm(latest_features - kmeans.cluster_centers_[latest_cluster])
            max_distance = np.max([np.linalg.norm(f - kmeans.cluster_centers_[latest_cluster]) 
                                  for f in scaled_features])
            confidence = 1.0 - (centroid_distance / max_distance)
            
            # Determine regime based on cluster
            if latest_cluster == bull_cluster:
                regime = "bullish_cluster"
            elif latest_cluster == bear_cluster:
                regime = "bearish_cluster"
            else:
                regime = "neutral_cluster"
            
            return {
                "regime": regime,
                "confidence": confidence,
                "details": {
                    "cluster": int(latest_cluster),
                    "centroid_distance": float(centroid_distance),
                    "cluster_stats": {k: {kk: float(vv) if isinstance(vv, (int, float, np.number)) else vv 
                                         for kk, vv in v.items()}
                                     for k, v in cluster_stats.items()}
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error in regime clustering: {e}", exc_info=True)
            return {"regime": "unknown", "confidence": 0.0, "details": {}}
    
    def _combine_regime_results(self, results):
        """
        Combine results from multiple detection methods.
        
        Args:
            results: Dict with results from different methods
            
        Returns:
            dict: Combined regime result
        """
        try:
            # Group similar regimes
            regime_groups = {
                "bullish": ["uptrend", "breakout", "high_volume_bullish", "bullish_cluster"],
                "bearish": ["downtrend", "breakdown", "high_volume_bearish", "bearish_cluster"],
                "neutral": ["sideways", "range_bound", "neutral_cluster"],
                "volatile": ["high_volatility", "trending_fat_tails"],
                "low_volatility": ["low_volatility", "consolidation", "low_volume"],
                "mean_reverting": ["mean_reverting_normal", "mean_reverting_nonnormal"],
                "support_resistance": ["near_support", "near_resistance"]
            }
            
            # Count regimes by group
            group_counts = {group: 0 for group in regime_groups}
            group_confidences = {group: [] for group in regime_groups}
            
            for method, result in results.items():
                regime = result["regime"]
                confidence = result["confidence"]
                
                for group, regimes in regime_groups.items():
                    if regime in regimes:
                        group_counts[group] += 1
                        group_confidences[group].append(confidence)
            
            # Find dominant regime group
            if not group_counts:
                return {"regime": "unknown", "confidence": 0.0, "details": {}}
            
            dominant_group = max(group_counts.items(), key=lambda x: x[1])[0]
            
            # If there's a tie, use the one with higher confidence
            max_count = group_counts[dominant_group]
            tied_groups = [g for g, c in group_counts.items() if c == max_count]
            
            if len(tied_groups) > 1:
                avg_confidences = {g: sum(group_confidences[g]) / len(group_confidences[g]) 
                                  if group_confidences[g] else 0
                                  for g in tied_groups}
                dominant_group = max(avg_confidences.items(), key=lambda x: x[1])[0]
            
            # Calculate overall confidence
            if group_confidences[dominant_group]:
                overall_confidence = (sum(group_confidences[dominant_group]) / 
                                     len(group_confidences[dominant_group]))
                # Adjust confidence based on agreement level
                agreement_factor = group_counts[dominant_group] / sum(group_counts.values())
                overall_confidence = overall_confidence * agreement_factor
            else:
                overall_confidence = 0.0
            
            return {
                "regime": dominant_group,
                "confidence": overall_confidence,
                "details": {
                    "group_counts": group_counts,
                    "method_results": {k: {"regime": v["regime"], "confidence": v["confidence"]} 
                                      for k, v in results.items()}
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error combining regime results: {e}", exc_info=True)
            return {"regime": "unknown", "confidence": 0.0, "details": {}}
    
    def get_regime_history(self, symbol, limit=None):
        """
        Get history of detected regimes for a symbol.
        
        Args:
            symbol: Symbol to get history for
            limit: Maximum number of history entries to return
            
        Returns:
            list: Regime history
        """
        if symbol not in self.regime_history:
            return []
        
        history = self.regime_history[symbol]
        
        if limit is not None:
            history = history[-limit:]
        
        return history
    
    def get_regime_transition_probability(self, symbol, from_regime=None):
        """
        Calculate probability of transitioning between regimes.
        
        Args:
            symbol: Symbol to calculate for
            from_regime: Starting regime (if None, use current)
            
        Returns:
            dict: Transition probabilities
        """
        if symbol not in self.regime_history or len(self.regime_history[symbol]) < 10:
            return {}
        
        history = self.regime_history[symbol]
        regimes = [h["regime"] for h in history]
        
        # Count transitions
        transitions = {}
        for i in range(len(regimes) - 1):
            r1 = regimes[i]
            r2 = regimes[i + 1]
            
            if r1 not in transitions:
                transitions[r1] = {}
            
            if r2 not in transitions[r1]:
                transitions[r1][r2] = 0
            
            transitions[r1][r2] += 1
        
        # Calculate probabilities
        probabilities = {}
        for r1, destinations in transitions.items():
            total = sum(destinations.values())
            probabilities[r1] = {r2: count / total for r2, count in destinations.items()}
        
        # Return probabilities for specified regime
        if from_regime is not None:
            return probabilities.get(from_regime, {})
        
        return probabilities
    
    def predict_next_regime(self, symbol):
        """
        Predict the next likely regime based on transition probabilities.
        
        Args:
            symbol: Symbol to predict for
            
        Returns:
            dict: Prediction result
        """
        if symbol not in self.regime_history or len(self.regime_history[symbol]) < 10:
            return {"next_regime": "unknown", "probability": 0.0}
        
        current_regime = self.regime_history[symbol][-1]["regime"]
        transitions = self.get_regime_transition_probability(symbol, current_regime)
        
        if not transitions:
            return {"next_regime": "unknown", "probability": 0.0}
        
        # Find most likely next regime
        next_regime = max(transitions.items(), key=lambda x: x[1])[0]
        probability = transitions[next_regime]
        
        return {"next_regime": next_regime, "probability": probability}


# Example usage
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Create detector
    detector = MarketRegimeDetector()
    
    # Example data
    import yfinance as yf
    btc_data = yf.download("BTC-USD", start="2023-01-01", end="2023-03-01")
    
    # Detect regime
    regime = detector.detect_regime(btc_data, "BTC-USD")
    
    print(f"Detected regime: {regime['regime']} (confidence: {regime['confidence']:.2f})")
    print("Details:")
    for method, result in regime['details']['method_results'].items():
        print(f"  {method}: {result['regime']} (confidence: {result['confidence']:.2f})")
