import os
import pandas as pd
import numpy as np
import logging
import json
from datetime import datetime
import sqlite3
from pathlib import Path

class TimeSeriesDatabase:
    """
    Time-series database for storing and retrieving cryptocurrency market data.
    Implements efficient storage and querying for both real-time and historical data.
    """
    
    def __init__(self, db_path=None):
        """
        Initialize the TimeSeriesDatabase.
        
        Args:
            db_path (str): Path to the SQLite database file
        """
        self.logger = logging.getLogger("time_series_db")
        self.db_path = db_path or "data/market_data.db"
        
        # Create data directory if it doesn't exist
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        
        # Initialize database
        self._init_database()
        
        self.logger.info(f"TimeSeriesDatabase initialized at {self.db_path}")
    
    def _init_database(self):
        """
        Initialize the database schema.
        """
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Create tables if they don't exist
            
            # Bars table (OHLCV data)
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS bars (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                timestamp INTEGER NOT NULL,
                timeframe TEXT NOT NULL,
                open REAL NOT NULL,
                high REAL NOT NULL,
                low REAL NOT NULL,
                close REAL NOT NULL,
                volume REAL NOT NULL,
                trade_count INTEGER,
                vwap REAL,
                source TEXT DEFAULT 'alpaca',
                UNIQUE(symbol, timestamp, timeframe)
            )
            ''')
            
            # Trades table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS trades (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                timestamp INTEGER NOT NULL,
                price REAL NOT NULL,
                size REAL NOT NULL,
                trade_id TEXT,
                exchange TEXT,
                source TEXT DEFAULT 'alpaca',
                UNIQUE(symbol, timestamp, trade_id)
            )
            ''')
            
            # Quotes table
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS quotes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                symbol TEXT NOT NULL,
                timestamp INTEGER NOT NULL,
                bid_price REAL NOT NULL,
                bid_size REAL NOT NULL,
                ask_price REAL NOT NULL,
                ask_size REAL NOT NULL,
                exchange TEXT,
                source TEXT DEFAULT 'alpaca',
                UNIQUE(symbol, timestamp)
            )
            ''')
            
            # Create indexes for faster queries
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_bars_symbol_timestamp ON bars (symbol, timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_trades_symbol_timestamp ON trades (symbol, timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_quotes_symbol_timestamp ON quotes (symbol, timestamp)')
            
            conn.commit()
            conn.close()
            
            self.logger.info("Database schema initialized")
            
        except Exception as e:
            self.logger.error(f"Error initializing database: {e}", exc_info=True)
            raise
    
    def store_bar(self, bar_data):
        """
        Store bar data in the database.
        
        Args:
            bar_data (dict): Bar data from Alpaca or other sources
            
        Returns:
            bool: Success status
        """
        try:
            # Normalize data format
            normalized_data = self._normalize_bar_data(bar_data)
            if not normalized_data:
                return False
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Insert data
            cursor.execute('''
            INSERT OR REPLACE INTO bars 
            (symbol, timestamp, timeframe, open, high, low, close, volume, trade_count, vwap, source)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                normalized_data['symbol'],
                normalized_data['timestamp'],
                normalized_data['timeframe'],
                normalized_data['open'],
                normalized_data['high'],
                normalized_data['low'],
                normalized_data['close'],
                normalized_data['volume'],
                normalized_data.get('trade_count'),
                normalized_data.get('vwap'),
                normalized_data.get('source', 'alpaca')
            ))
            
            conn.commit()
            conn.close()
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error storing bar data: {e}", exc_info=True)
            return False
    
    def store_trade(self, trade_data):
        """
        Store trade data in the database.
        
        Args:
            trade_data (dict): Trade data from Alpaca or other sources
            
        Returns:
            bool: Success status
        """
        try:
            # Normalize data format
            normalized_data = self._normalize_trade_data(trade_data)
            if not normalized_data:
                return False
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Insert data
            cursor.execute('''
            INSERT OR REPLACE INTO trades 
            (symbol, timestamp, price, size, trade_id, exchange, source)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                normalized_data['symbol'],
                normalized_data['timestamp'],
                normalized_data['price'],
                normalized_data['size'],
                normalized_data.get('trade_id'),
                normalized_data.get('exchange'),
                normalized_data.get('source', 'alpaca')
            ))
            
            conn.commit()
            conn.close()
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error storing trade data: {e}", exc_info=True)
            return False
    
    def store_quote(self, quote_data):
        """
        Store quote data in the database.
        
        Args:
            quote_data (dict): Quote data from Alpaca or other sources
            
        Returns:
            bool: Success status
        """
        try:
            # Normalize data format
            normalized_data = self._normalize_quote_data(quote_data)
            if not normalized_data:
                return False
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Insert data
            cursor.execute('''
            INSERT OR REPLACE INTO quotes 
            (symbol, timestamp, bid_price, bid_size, ask_price, ask_size, exchange, source)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                normalized_data['symbol'],
                normalized_data['timestamp'],
                normalized_data['bid_price'],
                normalized_data['bid_size'],
                normalized_data['ask_price'],
                normalized_data['ask_size'],
                normalized_data.get('exchange'),
                normalized_data.get('source', 'alpaca')
            ))
            
            conn.commit()
            conn.close()
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error storing quote data: {e}", exc_info=True)
            return False
    
    def get_bars(self, symbol, start_timestamp, end_timestamp, timeframe='1Min'):
        """
        Retrieve bar data from the database.
        
        Args:
            symbol (str): Cryptocurrency symbol
            start_timestamp (int): Start timestamp in milliseconds
            end_timestamp (int): End timestamp in milliseconds
            timeframe (str): Timeframe of the bars
            
        Returns:
            pandas.DataFrame: Bar data
        """
        try:
            conn = sqlite3.connect(self.db_path)
            
            query = '''
            SELECT timestamp, open, high, low, close, volume, trade_count, vwap
            FROM bars
            WHERE symbol = ? AND timestamp >= ? AND timestamp <= ? AND timeframe = ?
            ORDER BY timestamp
            '''
            
            df = pd.read_sql_query(
                query, 
                conn, 
                params=(symbol, start_timestamp, end_timestamp, timeframe)
            )
            
            conn.close()
            
            if not df.empty:
                # Convert timestamp to datetime
                df['datetime'] = pd.to_datetime(df['timestamp'], unit='ms')
                df.set_index('datetime', inplace=True)
            
            return df
            
        except Exception as e:
            self.logger.error(f"Error retrieving bar data: {e}", exc_info=True)
            return pd.DataFrame()
    
    def get_trades(self, symbol, start_timestamp, end_timestamp):
        """
        Retrieve trade data from the database.
        
        Args:
            symbol (str): Cryptocurrency symbol
            start_timestamp (int): Start timestamp in milliseconds
            end_timestamp (int): End timestamp in milliseconds
            
        Returns:
            pandas.DataFrame: Trade data
        """
        try:
            conn = sqlite3.connect(self.db_path)
            
            query = '''
            SELECT timestamp, price, size, trade_id, exchange
            FROM trades
            WHERE symbol = ? AND timestamp >= ? AND timestamp <= ?
            ORDER BY timestamp
            '''
            
            df = pd.read_sql_query(
                query, 
                conn, 
                params=(symbol, start_timestamp, end_timestamp)
            )
            
            conn.close()
            
            if not df.empty:
                # Convert timestamp to datetime
                df['datetime'] = pd.to_datetime(df['timestamp'], unit='ms')
                df.set_index('datetime', inplace=True)
            
            return df
            
        except Exception as e:
            self.logger.error(f"Error retrieving trade data: {e}", exc_info=True)
            return pd.DataFrame()
    
    def get_quotes(self, symbol, start_timestamp, end_timestamp):
        """
        Retrieve quote data from the database.
        
        Args:
            symbol (str): Cryptocurrency symbol
            start_timestamp (int): Start timestamp in milliseconds
            end_timestamp (int): End timestamp in milliseconds
            
        Returns:
            pandas.DataFrame: Quote data
        """
        try:
            conn = sqlite3.connect(self.db_path)
            
            query = '''
            SELECT timestamp, bid_price, bid_size, ask_price, ask_size, exchange
            FROM quotes
            WHERE symbol = ? AND timestamp >= ? AND timestamp <= ?
            ORDER BY timestamp
            '''
            
            df = pd.read_sql_query(
                query, 
                conn, 
                params=(symbol, start_timestamp, end_timestamp)
            )
            
            conn.close()
            
            if not df.empty:
                # Convert timestamp to datetime
                df['datetime'] = pd.to_datetime(df['timestamp'], unit='ms')
                df.set_index('datetime', inplace=True)
            
            return df
            
        except Exception as e:
            self.logger.error(f"Error retrieving quote data: {e}", exc_info=True)
            return pd.DataFrame()
    
    def _normalize_bar_data(self, bar_data):
        """
        Normalize bar data to a standard format.
        
        Args:
            bar_data (dict): Bar data from Alpaca or other sources
            
        Returns:
            dict: Normalized bar data
        """
        try:
            # Handle Alpaca format
            if 'S' in bar_data and 't' in bar_data:
                return {
                    'symbol': bar_data['S'],
                    'timestamp': bar_data['t'],
                    'timeframe': '1Min',  # Default for streaming data
                    'open': bar_data['o'],
                    'high': bar_data['h'],
                    'low': bar_data['l'],
                    'close': bar_data['c'],
                    'volume': bar_data['v'],
                    'trade_count': bar_data.get('n'),
                    'vwap': bar_data.get('vw'),
                    'source': 'alpaca'
                }
            
            # Handle already normalized format
            elif all(k in bar_data for k in ['symbol', 'timestamp', 'open', 'high', 'low', 'close', 'volume']):
                return {
                    'symbol': bar_data['symbol'],
                    'timestamp': bar_data['timestamp'],
                    'timeframe': bar_data.get('timeframe', '1Min'),
                    'open': bar_data['open'],
                    'high': bar_data['high'],
                    'low': bar_data['low'],
                    'close': bar_data['close'],
                    'volume': bar_data['volume'],
                    'trade_count': bar_data.get('trade_count'),
                    'vwap': bar_data.get('vwap'),
                    'source': bar_data.get('source', 'unknown')
                }
            
            else:
                self.logger.error(f"Unknown bar data format: {bar_data}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error normalizing bar data: {e}", exc_info=True)
            return None
    
    def _normalize_trade_data(self, trade_data):
        """
        Normalize trade data to a standard format.
        
        Args:
            trade_data (dict): Trade data from Alpaca or other sources
            
        Returns:
            dict: Normalized trade data
        """
        try:
            # Handle Alpaca format
            if 'S' in trade_data and 't' in trade_data:
                return {
                    'symbol': trade_data['S'],
                    'timestamp': trade_data['t'],
                    'price': trade_data['p'],
                    'size': trade_data['s'],
                    'trade_id': trade_data.get('i'),
                    'exchange': trade_data.get('x'),
                    'source': 'alpaca'
                }
            
            # Handle already normalized format
            elif all(k in trade_data for k in ['symbol', 'timestamp', 'price', 'size']):
                return {
                    'symbol': trade_data['symbol'],
                    'timestamp': trade_data['timestamp'],
                    'price': trade_data['price'],
                    'size': trade_data['size'],
                    'trade_id': trade_data.get('trade_id'),
                    'exchange': trade_data.get('exchange'),
                    'source': trade_data.get('source', 'unknown')
                }
            
            else:
                self.logger.error(f"Unknown trade data format: {trade_data}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error normalizing trade data: {e}", exc_info=True)
            return None
    
    def _normalize_quote_data(self, quote_data):
        """
        Normalize quote data to a standard format.
        
        Args:
            quote_data (dict): Quote data from Alpaca or other sources
            
        Returns:
            dict: Normalized quote data
        """
        try:
            # Handle Alpaca format
            if 'S' in quote_data and 't' in quote_data:
                return {
                    'symbol': quote_data['S'],
                    'timestamp': quote_data['t'],
                    'bid_price': quote_data['bp'],
                    'bid_size': quote_data['bs'],
                    'ask_price': quote_data['ap'],
                    'ask_size': quote_data['as'],
                    'exchange': quote_data.get('x'),
                    'source': 'alpaca'
                }
            
            # Handle already normalized format
            elif all(k in quote_data for k in ['symbol', 'timestamp', 'bid_price', 'bid_size', 'ask_price', 'ask_size']):
                return {
                    'symbol': quote_data['symbol'],
                    'timestamp': quote_data['timestamp'],
                    'bid_price': quote_data['bid_price'],
                    'bid_size': quote_data['bid_size'],
                    'ask_price': quote_data['ask_price'],
                    'ask_size': quote_data['ask_size'],
                    'exchange': quote_data.get('exchange'),
                    'source': quote_data.get('source', 'unknown')
                }
            
            else:
                self.logger.error(f"Unknown quote data format: {quote_data}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error normalizing quote data: {e}", exc_info=True)
            return None
    
    def import_csv_data(self, csv_file, data_type='bars', symbol=None, timeframe=None):
        """
        Import data from CSV file.
        
        Args:
            csv_file (str): Path to CSV file
            data_type (str): Type of data ('bars', 'trades', 'quotes')
            symbol (str): Symbol to use if not in CSV
            timeframe (str): Timeframe to use if not in CSV (for bars)
            
        Returns:
            bool: Success status
        """
        try:
            self.logger.info(f"Importing {data_type} data from {csv_file}")
            
            # Read CSV file
            df = pd.read_csv(csv_file)
            
            # Check if required columns exist
            if data_type == 'bars':
                required_columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume']
            elif data_type == 'trades':
                required_columns = ['timestamp', 'price', 'size']
            elif data_type == 'quotes':
                required_columns = ['timestamp', 'bid_price', 'bid_size', 'ask_price', 'ask_size']
            else:
                self.logger.error(f"Unknown data type: {data_type}")
                return False
            
            # Check if all required columns exist
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                self.logger.error(f"Missing columns in CSV: {missing_columns}")
                return False
            
            # Get symbol from CSV or parameter
            if 'symbol' in df.columns:
                symbols = df['symbol'].unique()
                if len(symbols) > 1:
                    self.logger.warning(f"Multiple symbols in CSV: {symbols}")
            elif symbol:
                df['symbol'] = symbol
            else:
                self.logger.error("Symbol not provided and not in CSV")
                return False
            
            # Get timeframe for bars
            if data_type == 'bars':
                if 'timeframe' in df.columns:
                    timeframes = df['timeframe'].unique()
                    if len(timeframes) > 1:
                        self.logger.warning(f"Multiple timeframes in CSV: {timeframes}")
                elif timeframe:
                    df['timeframe'] = timeframe
                else:
                    df['timeframe'] = '1Min'  # Default
            
            # Convert datetime to timestamp if needed
            if 'datetime' in df.columns and 'timestamp' not in df.columns:
                df['timestamp'] = pd.to_datetime(df['datetime']).astype(int) // 10**6
            
            # Import data
            conn = sqlite3.connect(self.db_path)
            
            if data_type == 'bars':
                df.to_sql('bars', conn, if_exists='append', index=False, 
                          method='multi', chunksize=1000)
            elif data_type == 'trades':
                df.to_sql('trades', conn, if_exists='append', index=False, 
                          method='multi', chunksize=1000)
            elif data_type == 'quotes':
                df.to_sql('quotes', conn, if_exists='append', index=False, 
                          method='multi', chunksize=1000)
            
            conn.close()
            
            self.logger.info(f"Imported {len(df)} rows of {data_type} data")
            return True
            
        except Exception as e:
            self.logger.error(f"Error importing CSV data: {e}", exc_info=True)
            return False
    
    def export_to_csv(self, symbol, start_timestamp, end_timestamp, data_type='bars', timeframe='1Min', output_file=None):
        """
        Export data to CSV file.
        
        Args:
            symbol (str): Cryptocurrency symbol
            start_timestamp (int): Start timestamp in milliseconds
            end_timestamp (int): End timestamp in milliseconds
            data_type (str): Type of data ('bars', 'trades', 'quotes')
            timeframe (str): Timeframe of the bars (for bars)
            output_file (str): Output file path
            
        Returns:
            str: Path to the output file
        """
        try:
            # Get data
            if data_type == 'bars':
                df = self.get_bars(symbol, start_timestamp, end_timestamp, timeframe)
            elif data_type == 'trades':
                df = self.get_trades(symbol, start_timestamp, end_timestamp)
            elif data_type == 'quotes':
                df = self.get_quotes(symbol, start_timestamp, end_timestamp)
            else:
                self.logger.error(f"Unknown data type: {data_type}")
                return None
            
            if df.empty:
                self.logger.warning(f"No {data_type} data found for {symbol}")
                return None
            
            # Generate output file path if not provided
            if not output_file:
                start_date = datetime.fromtimestamp(start_timestamp / 1000).strftime('%Y%m%d')
                end_date = datetime.fromtimestamp(end_timestamp / 1000).strftime('%Y%m%d')
                
                if data_type == 'bars':
                    output_file = f"data/export/{symbol.replace('/', '_')}_{timeframe}_{start_date}_{end_date}.csv"
                else:
                    output_file = f"data/export/{symbol.replace('/', '_')}_{data_type}_{start_date}_{end_date}.csv"
            
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(output_file), exist_ok=True)
            
            # Export to CSV
            df.to_csv(output_file)
            
            self.logger.info(f"Exported {len(df)} rows of {data_type} data to {output_file}")
            return output_file
            
        except Exception as e:
            self.logger.error(f"Error exporting data to CSV: {e}", exc_info=True)
            return None

# Example usage
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Create database
    db = TimeSeriesDatabase("data/test_market_data.db")
    
    # Test storing bar data
    bar_data = {
        'S': 'BTC/USD',
        't': int(datetime.now().timestamp() * 1000),
        'o': 50000.0,
        'h': 51000.0,
        'l': 49000.0,
        'c': 50500.0,
        'v': 10.5,
        'n': 100,
        'vw': 50200.0
    }
    
    success = db.store_bar(bar_data)
    print(f"Store bar data: {success}")
    
    # Test retrieving bar data
    now = int(datetime.now().timestamp() * 1000)
    one_day_ago = now - (24 * 60 * 60 * 1000)
    
    bars = db.get_bars('BTC/USD', one_day_ago, now)
    print(f"Retrieved {len(bars)} bars")
    print(bars.head())
