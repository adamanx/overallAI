import os
import logging
import pandas as pd
import numpy as np
from datetime import datetime
from typing import Dict, List, Union, Optional, Tuple, Any
from src.backtest_engine import TradingStrategy
from src.ml_model_manager import MLModelManager
from src.feature_engineering_pipeline import FeatureEngineeringPipeline

class RiskManager:
    """
    Risk management system for cryptocurrency trading strategies.
    Handles position sizing, stop-loss, take-profit, and risk allocation.
    """
    
    def __init__(self):
        """Initialize the RiskManager."""
        self.logger = logging.getLogger("risk_manager")
        self.logger.info("RiskManager initialized")
    
    def calculate_position_size(self, capital: float, risk_per_trade: float, 
                              entry_price: float, stop_price: float) -> float:
        """
        Calculate position size based on risk per trade.
        
        Args:
            capital: Available capital
            risk_per_trade: Percentage of capital to risk per trade
            entry_price: Entry price
            stop_price: Stop-loss price
            
        Returns:
            Position size
        """
        try:
            # Calculate risk amount in currency
            risk_amount = capital * risk_per_trade
            
            # Calculate price difference
            price_diff = abs(entry_price - stop_price)
            
            # Calculate position size
            if price_diff > 0:
                position_size = risk_amount / price_diff
            else:
                position_size = 0
                self.logger.warning("Invalid price difference for position sizing")
            
            return position_size
            
        except Exception as e:
            self.logger.error(f"Error calculating position size: {e}", exc_info=True)
            return 0
    
    def calculate_kelly_position_size(self, capital: float, win_rate: float, 
                                    win_loss_ratio: float, max_risk: float = 0.2) -> float:
        """
        Calculate position size using Kelly Criterion.
        
        Args:
            capital: Available capital
            win_rate: Probability of winning
            win_loss_ratio: Ratio of average win to average loss
            max_risk: Maximum risk percentage
            
        Returns:
            Position size as percentage of capital
        """
        try:
            # Calculate Kelly percentage
            kelly_pct = win_rate - ((1 - win_rate) / win_loss_ratio)
            
            # Apply maximum risk constraint
            position_pct = min(kelly_pct, max_risk)
            
            # Ensure position percentage is positive
            position_pct = max(position_pct, 0)
            
            # Calculate position size
            position_size = capital * position_pct
            
            return position_size
            
        except Exception as e:
            self.logger.error(f"Error calculating Kelly position size: {e}", exc_info=True)
            return 0
    
    def calculate_volatility_adjusted_stop(self, price: float, atr: float, 
                                         multiplier: float = 2.0) -> float:
        """
        Calculate volatility-adjusted stop-loss price.
        
        Args:
            price: Current price
            atr: Average True Range
            multiplier: ATR multiplier
            
        Returns:
            Stop-loss price
        """
        try:
            # Calculate stop distance
            stop_distance = atr * multiplier
            
            # Calculate stop price
            stop_price = price - stop_distance
            
            return stop_price
            
        except Exception as e:
            self.logger.error(f"Error calculating volatility-adjusted stop: {e}", exc_info=True)
            return price * 0.95  # Default to 5% below price
    
    def calculate_risk_reward_ratio(self, entry_price: float, stop_price: float, 
                                  target_price: float) -> float:
        """
        Calculate risk-reward ratio.
        
        Args:
            entry_price: Entry price
            stop_price: Stop-loss price
            target_price: Take-profit price
            
        Returns:
            Risk-reward ratio
        """
        try:
            # Calculate risk and reward
            risk = abs(entry_price - stop_price)
            reward = abs(target_price - entry_price)
            
            # Calculate ratio
            if risk > 0:
                ratio = reward / risk
            else:
                ratio = 0
                self.logger.warning("Invalid risk for risk-reward calculation")
            
            return ratio
            
        except Exception as e:
            self.logger.error(f"Error calculating risk-reward ratio: {e}", exc_info=True)
            return 0
    
    def calculate_max_drawdown_stop(self, equity: float, peak_equity: float, 
                                  max_drawdown: float = 0.1) -> bool:
        """
        Check if maximum drawdown stop is triggered.
        
        Args:
            equity: Current equity
            peak_equity: Peak equity
            max_drawdown: Maximum allowed drawdown
            
        Returns:
            True if stop is triggered, False otherwise
        """
        try:
            # Calculate current drawdown
            if peak_equity > 0:
                drawdown = (peak_equity - equity) / peak_equity
            else:
                drawdown = 0
            
            # Check if drawdown exceeds maximum
            if drawdown >= max_drawdown:
                return True
            else:
                return False
                
        except Exception as e:
            self.logger.error(f"Error calculating max drawdown stop: {e}", exc_info=True)
            return False
    
    def calculate_portfolio_heat(self, positions: List[Dict], capital: float) -> float:
        """
        Calculate portfolio heat (total risk exposure).
        
        Args:
            positions: List of position dictionaries
            capital: Total capital
            
        Returns:
            Portfolio heat as percentage of capital
        """
        try:
            # Calculate total risk
            total_risk = sum(position.get('risk_amount', 0) for position in positions)
            
            # Calculate portfolio heat
            if capital > 0:
                portfolio_heat = total_risk / capital
            else:
                portfolio_heat = 0
                self.logger.warning("Invalid capital for portfolio heat calculation")
            
            return portfolio_heat
            
        except Exception as e:
            self.logger.error(f"Error calculating portfolio heat: {e}", exc_info=True)
            return 0

class AdvancedTradingStrategy(TradingStrategy):
    """
    Advanced trading strategy with comprehensive risk management.
    Combines multiple signals and risk management techniques.
    """
    
    def __init__(self, name="AdvancedTrading", risk_per_trade=0.02, max_portfolio_risk=0.1,
                max_drawdown=0.15, atr_multiplier=2.0, min_risk_reward=2.0):
        """
        Initialize the AdvancedTradingStrategy.
        
        Args:
            name: Strategy name
            risk_per_trade: Percentage of capital to risk per trade
            max_portfolio_risk: Maximum portfolio risk
            max_drawdown: Maximum allowed drawdown
            atr_multiplier: ATR multiplier for stop-loss
            min_risk_reward: Minimum risk-reward ratio for trades
        """
        super().__init__(name)
        
        # Risk parameters
        self.risk_per_trade = risk_per_trade
        self.max_portfolio_risk = max_portfolio_risk
        self.max_drawdown = max_drawdown
        self.atr_multiplier = atr_multiplier
        self.min_risk_reward = min_risk_reward
        
        # Initialize risk manager
        self.risk_manager = RiskManager()
        
        # Initialize ML model manager
        self.model_manager = MLModelManager()
        
        # Initialize feature engineering pipeline
        self.feature_pipeline = FeatureEngineeringPipeline()
        
        # Strategy state
        self.models = {}
        self.peak_equity = 0
        self.positions = []
        self.trade_history = []
        self.win_rate = 0.5  # Initial estimate
        self.win_loss_ratio = 1.0  # Initial estimate
        
        self.logger.info(f"AdvancedTradingStrategy initialized with risk_per_trade={risk_per_trade}, max_portfolio_risk={max_portfolio_risk}")
    
    def initialize(self, symbol, timeframe, initial_capital=10000.0, commission=0.001, slippage=0.0005):
        """
        Initialize the strategy with parameters.
        
        Args:
            symbol: Cryptocurrency symbol
            timeframe: Timeframe of the data
            initial_capital: Initial capital for the backtest
            commission: Commission rate per trade
            slippage: Slippage rate per trade
        """
        super().initialize(symbol, timeframe, initial_capital, commission, slippage)
        
        # Reset strategy state
        self.peak_equity = initial_capital
        self.positions = []
        self.trade_history = []
        
        # Load models
        self.models = self.model_manager.get_best_models(symbol, timeframe)
        
        if not self.models:
            self.logger.warning(f"No models found for {symbol} {timeframe}")
        else:
            self.logger.info(f"Loaded {len(self.models)} models for {symbol} {timeframe}")
    
    def on_bar(self, timestamp, bar):
        """
        Process a new bar.
        
        Args:
            timestamp: Bar timestamp
            bar: Bar data
        """
        super().on_bar(timestamp, bar)
        
        # Update peak equity
        current_equity = self.cash + self.position * bar['close']
        self.peak_equity = max(self.peak_equity, current_equity)
        
        # Check for maximum drawdown stop
        if self.risk_manager.calculate_max_drawdown_stop(current_equity, self.peak_equity, self.max_drawdown):
            self.logger.warning(f"Maximum drawdown of {self.max_drawdown:.1%} reached, exiting all positions")
            # This will be handled in generate_signals
    
    def generate_signals(self, timestamp, bar):
        """
        Generate trading signals.
        
        Args:
            timestamp: Bar timestamp
            bar: Bar data
            
        Returns:
            List of signal dictionaries
        """
        signals = []
        
        # Get current price
        price = bar['close']
        
        # Check for maximum drawdown stop
        current_equity = self.cash + self.position * price
        if self.risk_manager.calculate_max_drawdown_stop(current_equity, self.peak_equity, self.max_drawdown):
            if self.position > 0:
                signals.append({
                    'type': 'exit',
                    'reason': 'max_drawdown',
                    'size': self.position
                })
                self.logger.info(f"Maximum drawdown exit at {price}")
                return signals
        
        # Check for exit signals if we have a position
        if self.position > 0:
            # Check for exit signals from models
            features_df = pd.DataFrame([bar])
            predictions = self.model_manager.predict_with_models(features_df, self.models)
            
            # Check direction prediction
            if 'direction' in predictions and len(predictions['direction']) > 0:
                direction_prob = predictions['direction'][0]
                
                # Exit if direction probability is low
                if direction_prob < 0.3:
                    signals.append({
                        'type': 'exit',
                        'reason': 'model_signal',
                        'size': self.position
                    })
                    self.logger.info(f"Model-based exit at {price}")
                    return signals
            
            # Check for trailing stop
            if hasattr(self, 'highest_price') and price < self.highest_price * 0.95:
                signals.append({
                    'type': 'exit',
                    'reason': 'trailing_stop',
                    'size': self.position
                })
                self.logger.info(f"Trailing stop exit at {price}")
                return signals
            
            # Update highest price
            if not hasattr(self, 'highest_price') or price > self.highest_price:
                self.highest_price = price
        
        # Check for entry signals if we don't have a position
        if self.position == 0:
            # Check portfolio heat
            portfolio_heat = self.risk_manager.calculate_portfolio_heat(self.positions, self.cash)
            if portfolio_heat >= self.max_portfolio_risk:
                self.logger.info(f"Maximum portfolio risk reached ({portfolio_heat:.1%}), skipping entry")
                return signals
            
            # Make predictions
            features_df = pd.DataFrame([bar])
            predictions = self.model_manager.predict_with_models(features_df, self.models)
            
            # Check for spike signals
            spike_signal = False
            spike_prob = 0
            
            if 'spike_binary' in predictions and len(predictions['spike_binary']) > 0:
                spike_prob = predictions['spike_binary'][0]
                
                # Check if probability exceeds threshold
                if spike_prob > 0.7:
                    spike_signal = True
            
            # Check direction prediction
            direction_signal = False
            
            if 'direction' in predictions and len(predictions['direction']) > 0:
                direction_prob = predictions['direction'][0]
                
                # Check if probability exceeds threshold
                if direction_prob > 0.7:
                    direction_signal = True
            
            # Check price change prediction
            change_signal = False
            
            if 'change' in predictions and len(predictions['change']) > 0:
                change_pred = predictions['change'][0]
                
                # Check if predicted change is positive and significant
                if change_pred > 1.0:
                    change_signal = True
            
            # Combine signals
            entry_signal = (spike_signal and direction_signal) or (direction_signal and change_signal)
            
            if entry_signal:
                # Calculate ATR if available
                atr = bar.get('atr_14', price * 0.02)  # Default to 2% of price
                
                # Calculate stop price
                stop_price = self.risk_manager.calculate_volatility_adjusted_stop(price, atr, self.atr_multiplier)
                
                # Calculate target price
                price_diff = price - stop_price
                target_price = price + (price_diff * self.min_risk_reward)
                
                # Check risk-reward ratio
                risk_reward = self.risk_manager.calculate_risk_reward_ratio(price, stop_price, target_price)
                
                if risk_reward >= self.min_risk_reward:
                    # Calculate position size
                    position_size = self.risk_manager.calculate_position_size(
                        self.cash, self.risk_per_trade, price, stop_price
                    )
                    
                    # Generate buy signal
                    signals.append({
                        'type': 'buy',
                        'reason': 'combined_signal',
                        'size': position_size,
                        'stop_price': stop_price,
                        'target_price': target_price,
                        'risk_reward': risk_reward
                    })
                    
                    # Update strategy state
                    self.highest_price = price
                    
                    self.logger.info(f"Entry signal at {price}, stop: {stop_price}, target: {target_price}, R:R: {risk_reward:.2f}")
                else:
                    self.logger.info(f"Entry signal rejected due to insufficient risk-reward ratio ({risk_reward:.2f})")
        
        return signals
    
    def update_trade_statistics(self, trade_result):
        """
        Update trade statistics based on completed trade.
        
        Args:
            trade_result: Trade result dictionary
        """
        try:
            # Add to trade history
            self.trade_history.append(trade_result)
            
            # Calculate win rate
            wins = sum(1 for trade in self.trade_history if trade.get('pnl', 0) > 0)
            total_trades = len(self.trade_history)
            
            if total_trades > 0:
                self.win_rate = wins / total_trades
            
            # Calculate win/loss ratio
            winning_trades = [trade for trade in self.trade_history if trade.get('pnl', 0) > 0]
            losing_trades = [trade for trade in self.trade_history if trade.get('pnl', 0) <= 0]
            
            avg_win = sum(trade.get('pnl', 0) for trade in winning_trades) / len(winning_trades) if winning_trades else 0
            avg_loss = abs(sum(trade.get('pnl', 0) for trade in losing_trades) / len(losing_trades)) if losing_trades else 1
            
            if avg_loss > 0:
                self.win_loss_ratio = avg_win / avg_loss
            
            self.logger.info(f"Updated trade statistics: win rate: {self.win_rate:.2f}, win/loss ratio: {self.win_loss_ratio:.2f}")
            
        except Exception as e:
            self.logger.error(f"Error updating trade statistics: {e}", exc_info=True)
    
    def get_config(self):
        """
        Get strategy configuration.
        
        Returns:
            Dict with strategy configuration
        """
        config = super().get_config()
        config.update({
            'risk_per_trade': self.risk_per_trade,
            'max_portfolio_risk': self.max_portfolio_risk,
            'max_drawdown': self.max_drawdown,
            'atr_multiplier': self.atr_multiplier,
            'min_risk_reward': self.min_risk_reward
        })
        return config

class AdaptiveTradingStrategy(TradingStrategy):
    """
    Adaptive trading strategy that adjusts parameters based on market conditions.
    Uses machine learning models and adapts risk parameters dynamically.
    """
    
    def __init__(self, name="AdaptiveTrading", base_risk_per_trade=0.02, 
                max_risk_per_trade=0.05, min_risk_per_trade=0.01):
        """
        Initialize the AdaptiveTradingStrategy.
        
        Args:
            name: Strategy name
            base_risk_per_trade: Base percentage of capital to risk per trade
            max_risk_per_trade: Maximum percentage of capital to risk per trade
            min_risk_per_trade: Minimum percentage of capital to risk per trade
        """
        super().__init__(name)
        
        # Risk parameters
        self.base_risk_per_trade = base_risk_per_trade
        self.max_risk_per_trade = max_risk_per_trade
        self.min_risk_per_trade = min_risk_per_trade
        self.current_risk_per_trade = base_risk_per_trade
        
        # Initialize risk manager
        self.risk_manager = RiskManager()
        
        # Initialize ML model manager
        self.model_manager = MLModelManager()
        
        # Initialize feature engineering pipeline
        self.feature_pipeline = FeatureEngineeringPipeline()
        
        # Strategy state
        self.models = {}
        self.market_regime = 'normal'  # 'normal', 'volatile', 'trending'
        self.volatility_level = 1.0  # Relative to historical volatility
        self.trend_strength = 0.0  # 0.0 to 1.0
        self.win_rate = 0.5  # Initial estimate
        self.win_loss_ratio = 1.0  # Initial estimate
        self.consecutive_wins = 0
        self.consecutive_losses = 0
        
        # Performance tracking
        self.equity_curve = []
        self.drawdown_history = []
        
        self.logger.info(f"AdaptiveTradingStrategy initialized with base_risk_per_trade={base_risk_per_trade}")
    
    def initialize(self, symbol, timeframe, initial_capital=10000.0, commission=0.001, slippage=0.0005):
        """
        Initialize the strategy with parameters.
        
        Args:
            symbol: Cryptocurrency symbol
            timeframe: Timeframe of the data
            initial_capital: Initial capital for the backtest
            commission: Commission rate per trade
            slippage: Slippage rate per trade
        """
        super().initialize(symbol, timeframe, initial_capital, commission, slippage)
        
        # Reset strategy state
        self.market_regime = 'normal'
        self.volatility_level = 1.0
        self.trend_strength = 0.0
        self.current_risk_per_trade = self.base_risk_per_trade
        self.consecutive_wins = 0
        self.consecutive_losses = 0
        self.equity_curve = [initial_capital]
        self.drawdown_history = [0.0]
        
        # Load models
        self.models = self.model_manager.get_best_models(symbol, timeframe)
        
        if not self.models:
            self.logger.warning(f"No models found for {symbol} {timeframe}")
        else:
            self.logger.info(f"Loaded {len(self.models)} models for {symbol} {timeframe}")
    
    def on_bar(self, timestamp, bar):
        """
        Process a new bar.
        
        Args:
            timestamp: Bar timestamp
            bar: Bar data
        """
        super().on_bar(timestamp, bar)
        
        # Update equity curve
        current_equity = self.cash + self.position * bar['close']
        self.equity_curve.append(current_equity)
        
        # Update drawdown history
        peak_equity = max(self.equity_curve)
        current_drawdown = (peak_equity - current_equity) / peak_equity if peak_equity > 0 else 0
        self.drawdown_history.append(current_drawdown)
        
        # Detect market regime
        self._detect_market_regime(bar)
        
        # Adjust risk parameters
        self._adjust_risk_parameters()
    
    def _detect_market_regime(self, bar):
        """
        Detect current market regime.
        
        Args:
            bar: Bar data
        """
        try:
            # Check for volatility indicators
            if 'atr_14' in bar and 'atr_14_sma_20' in bar and bar['atr_14_sma_20'] > 0:
                # Calculate relative volatility
                self.volatility_level = bar['atr_14'] / bar['atr_14_sma_20']
            
            # Check for trend indicators
            if 'adx_14' in bar:
                # ADX above 25 indicates trending market
                self.trend_strength = min(bar['adx_14'] / 50, 1.0)
            elif 'sma_20' in bar and 'sma_50' in bar and 'sma_200' in bar:
                # Check moving average alignment
                if bar['sma_20'] > bar['sma_50'] > bar['sma_200']:
                    self.trend_strength = 0.8  # Strong uptrend
                elif bar['sma_20'] < bar['sma_50'] < bar['sma_200']:
                    self.trend_strength = 0.8  # Strong downtrend
                else:
                    self.trend_strength = 0.3  # Weak trend
            
            # Determine market regime
            if self.volatility_level > 1.5:
                self.market_regime = 'volatile'
            elif self.trend_strength > 0.6:
                self.market_regime = 'trending'
            else:
                self.market_regime = 'normal'
                
            self.logger.debug(f"Market regime: {self.market_regime}, volatility: {self.volatility_level:.2f}, trend: {self.trend_strength:.2f}")
            
        except Exception as e:
            self.logger.error(f"Error detecting market regime: {e}", exc_info=True)
    
    def _adjust_risk_parameters(self):
        """
        Adjust risk parameters based on market regime and performance.
        """
        try:
            # Base risk adjustment on market regime
            if self.market_regime == 'volatile':
                # Reduce risk in volatile markets
                regime_risk = self.base_risk_per_trade * 0.7
            elif self.market_regime == 'trending':
                # Increase risk in trending markets
                regime_risk = self.base_risk_per_trade * 1.3
            else:
                # Normal risk in normal markets
                regime_risk = self.base_risk_per_trade
            
            # Adjust based on recent performance
            performance_factor = 1.0
            
            if self.consecutive_wins >= 3:
                # Increase risk after consecutive wins
                performance_factor = 1.2
            elif self.consecutive_losses >= 2:
                # Decrease risk after consecutive losses
                performance_factor = 0.8
            
            # Calculate current risk per trade
            self.current_risk_per_trade = regime_risk * performance_factor
            
            # Ensure risk stays within bounds
            self.current_risk_per_trade = max(self.min_risk_per_trade, 
                                             min(self.max_risk_per_trade, self.current_risk_per_trade))
            
            self.logger.debug(f"Adjusted risk per trade: {self.current_risk_per_trade:.2%}")
            
        except Exception as e:
            self.logger.error(f"Error adjusting risk parameters: {e}", exc_info=True)
            self.current_risk_per_trade = self.base_risk_per_trade
    
    def generate_signals(self, timestamp, bar):
        """
        Generate trading signals.
        
        Args:
            timestamp: Bar timestamp
            bar: Bar data
            
        Returns:
            List of signal dictionaries
        """
        signals = []
        
        # Get current price
        price = bar['close']
        
        # Check for exit signals if we have a position
        if self.position > 0:
            # Check for exit signals from models
            features_df = pd.DataFrame([bar])
            predictions = self.model_manager.predict_with_models(features_df, self.models)
            
            # Check direction prediction
            if 'direction' in predictions and len(predictions['direction']) > 0:
                direction_prob = predictions['direction'][0]
                
                # Exit if direction probability is low
                if direction_prob < 0.3:
                    signals.append({
                        'type': 'exit',
                        'reason': 'model_signal',
                        'size': self.position
                    })
                    self.logger.info(f"Model-based exit at {price}")
                    
                    # Update consecutive wins/losses
                    if price > self.entry_price:
                        self.consecutive_wins += 1
                        self.consecutive_losses = 0
                    else:
                        self.consecutive_losses += 1
                        self.consecutive_wins = 0
                    
                    return signals
            
            # Check for trailing stop
            if hasattr(self, 'highest_price'):
                # Adjust trailing stop based on market regime
                if self.market_regime == 'volatile':
                    trail_pct = 0.08  # Wider trail in volatile markets
                elif self.market_regime == 'trending':
                    trail_pct = 0.05  # Medium trail in trending markets
                else:
                    trail_pct = 0.06  # Default trail
                
                if price < self.highest_price * (1 - trail_pct):
                    signals.append({
                        'type': 'exit',
                        'reason': 'trailing_stop',
                        'size': self.position
                    })
                    self.logger.info(f"Trailing stop exit at {price}")
                    
                    # Update consecutive wins/losses
                    if price > self.entry_price:
                        self.consecutive_wins += 1
                        self.consecutive_losses = 0
                    else:
                        self.consecutive_losses += 1
                        self.consecutive_wins = 0
                    
                    return signals
            
            # Update highest price
            if not hasattr(self, 'highest_price') or price > self.highest_price:
                self.highest_price = price
        
        # Check for entry signals if we don't have a position
        if self.position == 0:
            # Make predictions
            features_df = pd.DataFrame([bar])
            predictions = self.model_manager.predict_with_models(features_df, self.models)
            
            # Adjust entry threshold based on market regime
            if self.market_regime == 'volatile':
                direction_threshold = 0.75  # Higher threshold in volatile markets
                spike_threshold = 0.8
            elif self.market_regime == 'trending':
                direction_threshold = 0.65  # Lower threshold in trending markets
                spike_threshold = 0.65
            else:
                direction_threshold = 0.7  # Default threshold
                spike_threshold = 0.7
            
            # Check for spike signals
            spike_signal = False
            
            if 'spike_binary' in predictions and len(predictions['spike_binary']) > 0:
                spike_prob = predictions['spike_binary'][0]
                
                # Check if probability exceeds threshold
                if spike_prob > spike_threshold:
                    spike_signal = True
            
            # Check direction prediction
            direction_signal = False
            
            if 'direction' in predictions and len(predictions['direction']) > 0:
                direction_prob = predictions['direction'][0]
                
                # Check if probability exceeds threshold
                if direction_prob > direction_threshold:
                    direction_signal = True
            
            # Combine signals based on market regime
            if self.market_regime == 'trending' and direction_signal:
                entry_signal = True
            elif self.market_regime == 'volatile' and spike_signal and direction_signal:
                entry_signal = True
            elif self.market_regime == 'normal' and (spike_signal or direction_signal):
                entry_signal = True
            else:
                entry_signal = False
            
            if entry_signal:
                # Calculate ATR if available
                atr = bar.get('atr_14', price * 0.02)  # Default to 2% of price
                
                # Adjust ATR multiplier based on market regime
                if self.market_regime == 'volatile':
                    atr_multiplier = 2.5  # Wider stops in volatile markets
                elif self.market_regime == 'trending':
                    atr_multiplier = 1.5  # Tighter stops in trending markets
                else:
                    atr_multiplier = 2.0  # Default multiplier
                
                # Calculate stop price
                stop_price = self.risk_manager.calculate_volatility_adjusted_stop(price, atr, atr_multiplier)
                
                # Calculate position size using Kelly criterion
                kelly_size = self.risk_manager.calculate_kelly_position_size(
                    self.cash, self.win_rate, self.win_loss_ratio, self.current_risk_per_trade
                )
                
                # Calculate position size using fixed risk
                fixed_risk_size = self.risk_manager.calculate_position_size(
                    self.cash, self.current_risk_per_trade, price, stop_price
                )
                
                # Use the smaller of the two position sizes
                position_size = min(kelly_size, fixed_risk_size)
                
                # Adjust position size based on market regime
                if self.market_regime == 'volatile':
                    position_size *= 0.8  # Reduce position size in volatile markets
                elif self.market_regime == 'trending':
                    position_size *= 1.2  # Increase position size in trending markets
                
                # Generate buy signal
                signals.append({
                    'type': 'buy',
                    'reason': f'{self.market_regime}_regime',
                    'size': position_size,
                    'stop_price': stop_price
                })
                
                # Update strategy state
                self.highest_price = price
                self.entry_price = price
                
                self.logger.info(f"Entry signal at {price}, stop: {stop_price}, regime: {self.market_regime}")
        
        return signals
    
    def get_config(self):
        """
        Get strategy configuration.
        
        Returns:
            Dict with strategy configuration
        """
        config = super().get_config()
        config.update({
            'base_risk_per_trade': self.base_risk_per_trade,
            'max_risk_per_trade': self.max_risk_per_trade,
            'min_risk_per_trade': self.min_risk_per_trade,
            'current_risk_per_trade': self.current_risk_per_trade,
            'market_regime': self.market_regime,
            'volatility_level': self.volatility_level,
            'trend_strength': self.trend_strength
        })
        return config

# Example usage
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Create risk manager
    risk_manager = RiskManager()
    
    # Test position sizing
    capital = 10000.0
    risk_per_trade = 0.02
    entry_price = 50000.0
    stop_price = 48000.0
    
    position_size = risk_manager.calculate_position_size(capital, risk_per_trade, entry_price, stop_price)
    print(f"Position size: {position_size} BTC (${position_size * entry_price:.2f})")
    
    # Test Kelly criterion
    win_rate = 0.6
    win_loss_ratio = 2.0
    
    kelly_size = risk_manager.calculate_kelly_position_size(capital, win_rate, win_loss_ratio)
    print(f"Kelly position size: ${kelly_size:.2f} ({kelly_size / capital:.1%} of capital)")
    
    # Create advanced trading strategy
    advanced_strategy = AdvancedTradingStrategy(risk_per_trade=0.02, max_portfolio_risk=0.1)
    
    # Create adaptive trading strategy
    adaptive_strategy = AdaptiveTradingStrategy(base_risk_per_trade=0.02)
    
    print("Trading strategies created successfully")
