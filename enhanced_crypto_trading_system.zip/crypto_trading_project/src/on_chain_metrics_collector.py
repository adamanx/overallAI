import logging
import requests
import pandas as pd
import time
from datetime import datetime, timedelta

class OnChainMetricsCollector:
    """
    Collects on-chain metrics from Etherscan and Solscan for enhanced trading signals.
    """
    
    def __init__(self, etherscan_api_key=None, solscan_api_key=None):
        """
        Initialize the OnChainMetricsCollector.
        
        Args:
            etherscan_api_key: API key for Etherscan
            solscan_api_key: API key for Solscan
        """
        self.logger = logging.getLogger("on_chain_metrics_collector")
        self.etherscan_api_key = etherscan_api_key
        self.solscan_api_key = solscan_api_key
        
        # Base URLs for API endpoints
        self.etherscan_base_url = "https://api.etherscan.io/api"
        self.solscan_base_url = "https://public-api.solscan.io"
        
        # Cache for metrics to reduce API calls
        self.metrics_cache = {
            "eth": {},
            "sol": {}
        }
        
        self.logger.info("OnChainMetricsCollector initialized")
    
    def get_eth_metrics(self, metric_types=None, days=7):
        """
        Get Ethereum on-chain metrics.
        
        Args:
            metric_types: List of metric types to fetch (default: all)
            days: Number of days of historical data to fetch
            
        Returns:
            dict: Ethereum on-chain metrics
        """
        if metric_types is None:
            metric_types = [
                "transactions", 
                "gas", 
                "addresses", 
                "defi", 
                "whales",
                "network"
            ]
        
        results = {}
        
        for metric_type in metric_types:
            try:
                if metric_type == "transactions":
                    results[metric_type] = self._get_eth_transaction_metrics(days)
                elif metric_type == "gas":
                    results[metric_type] = self._get_eth_gas_metrics(days)
                elif metric_type == "addresses":
                    results[metric_type] = self._get_eth_address_metrics(days)
                elif metric_type == "defi":
                    results[metric_type] = self._get_eth_defi_metrics(days)
                elif metric_type == "whales":
                    results[metric_type] = self._get_eth_whale_metrics(days)
                elif metric_type == "network":
                    results[metric_type] = self._get_eth_network_metrics(days)
            except Exception as e:
                self.logger.error(f"Error fetching ETH {metric_type} metrics: {e}", exc_info=True)
                results[metric_type] = {}
        
        # Cache results
        cache_key = f"all_{days}"
        self.metrics_cache["eth"][cache_key] = {
            "timestamp": datetime.now(),
            "data": results
        }
        
        return results
    
    def get_sol_metrics(self, metric_types=None, days=7):
        """
        Get Solana on-chain metrics.
        
        Args:
            metric_types: List of metric types to fetch (default: all)
            days: Number of days of historical data to fetch
            
        Returns:
            dict: Solana on-chain metrics
        """
        if metric_types is None:
            metric_types = [
                "transactions", 
                "accounts", 
                "staking", 
                "nft", 
                "defi",
                "network"
            ]
        
        results = {}
        
        for metric_type in metric_types:
            try:
                if metric_type == "transactions":
                    results[metric_type] = self._get_sol_transaction_metrics(days)
                elif metric_type == "accounts":
                    results[metric_type] = self._get_sol_account_metrics(days)
                elif metric_type == "staking":
                    results[metric_type] = self._get_sol_staking_metrics(days)
                elif metric_type == "nft":
                    results[metric_type] = self._get_sol_nft_metrics(days)
                elif metric_type == "defi":
                    results[metric_type] = self._get_sol_defi_metrics(days)
                elif metric_type == "network":
                    results[metric_type] = self._get_sol_network_metrics(days)
            except Exception as e:
                self.logger.error(f"Error fetching SOL {metric_type} metrics: {e}", exc_info=True)
                results[metric_type] = {}
        
        # Cache results
        cache_key = f"all_{days}"
        self.metrics_cache["sol"][cache_key] = {
            "timestamp": datetime.now(),
            "data": results
        }
        
        return results
    
    def get_metrics_for_trading(self, asset):
        """
        Get on-chain metrics formatted for trading signals.
        
        Args:
            asset: Asset to get metrics for ("ETH" or "SOL")
            
        Returns:
            dict: On-chain metrics for trading
        """
        asset = asset.lower()
        
        if asset not in ["eth", "sol"]:
            self.logger.error(f"Unsupported asset: {asset}")
            return {}
        
        # Check cache first
        cache_key = "all_7"  # 7 days of data
        if asset in self.metrics_cache and cache_key in self.metrics_cache[asset]:
            cache_entry = self.metrics_cache[asset][cache_key]
            cache_age = datetime.now() - cache_entry["timestamp"]
            
            # Use cache if less than 1 hour old
            if cache_age < timedelta(hours=1):
                self.logger.info(f"Using cached {asset} metrics")
                metrics = cache_entry["data"]
            else:
                # Refresh cache
                self.logger.info(f"Refreshing {asset} metrics cache")
                if asset == "eth":
                    metrics = self.get_eth_metrics()
                else:
                    metrics = self.get_sol_metrics()
        else:
            # No cache, fetch metrics
            self.logger.info(f"Fetching {asset} metrics (no cache)")
            if asset == "eth":
                metrics = self.get_eth_metrics()
            else:
                metrics = self.get_sol_metrics()
        
        # Extract and format metrics for trading
        trading_metrics = self._extract_trading_metrics(metrics, asset)
        
        return trading_metrics
    
    def _extract_trading_metrics(self, metrics, asset):
        """
        Extract and format metrics for trading signals.
        
        Args:
            metrics: Raw metrics data
            asset: Asset type ("eth" or "sol")
            
        Returns:
            dict: Formatted metrics for trading
        """
        trading_metrics = {}
        
        try:
            # Common metrics for both ETH and SOL
            if "transactions" in metrics:
                tx_metrics = metrics["transactions"]
                if "daily_count" in tx_metrics:
                    # Calculate transaction growth rate
                    daily_counts = tx_metrics["daily_count"]
                    if len(daily_counts) >= 2:
                        current = daily_counts[-1]
                        previous = daily_counts[-2]
                        tx_growth = (current - previous) / previous if previous > 0 else 0
                        trading_metrics["tx_growth"] = tx_growth
                
                if "avg_value" in tx_metrics:
                    trading_metrics["avg_tx_value"] = tx_metrics["avg_value"]
            
            # Network metrics
            if "network" in metrics:
                network_metrics = metrics["network"]
                if "active_addresses" in network_metrics:
                    trading_metrics["active_addresses"] = network_metrics["active_addresses"][-1]
                
                if "new_addresses" in network_metrics:
                    trading_metrics["new_addresses"] = network_metrics["new_addresses"][-1]
            
            # Asset-specific metrics
            if asset == "eth":
                # ETH-specific metrics
                if "gas" in metrics:
                    gas_metrics = metrics["gas"]
                    if "avg_gas_price" in gas_metrics:
                        trading_metrics["avg_gas_price"] = gas_metrics["avg_gas_price"][-1]
                
                if "defi" in metrics:
                    defi_metrics = metrics["defi"]
                    if "total_value_locked" in defi_metrics:
                        trading_metrics["tvl"] = defi_metrics["total_value_locked"][-1]
                
                if "whales" in metrics:
                    whale_metrics = metrics["whales"]
                    if "whale_transaction_count" in whale_metrics:
                        trading_metrics["whale_txs"] = whale_metrics["whale_transaction_count"][-1]
            
            elif asset == "sol":
                # SOL-specific metrics
                if "staking" in metrics:
                    staking_metrics = metrics["staking"]
                    if "total_staked" in staking_metrics:
                        trading_metrics["total_staked"] = staking_metrics["total_staked"][-1]
                    
                    if "staking_yield" in staking_metrics:
                        trading_metrics["staking_yield"] = staking_metrics["staking_yield"][-1]
                
                if "nft" in metrics:
                    nft_metrics = metrics["nft"]
                    if "daily_volume" in nft_metrics:
                        trading_metrics["nft_volume"] = nft_metrics["daily_volume"][-1]
            
            # Calculate on-chain momentum
            trading_metrics["on_chain_momentum"] = self._calculate_on_chain_momentum(metrics, asset)
            
            # Calculate on-chain sentiment
            trading_metrics["on_chain_sentiment"] = self._calculate_on_chain_sentiment(metrics, asset)
            
        except Exception as e:
            self.logger.error(f"Error extracting trading metrics: {e}", exc_info=True)
        
        return trading_metrics
    
    def _calculate_on_chain_momentum(self, metrics, asset):
        """
        Calculate on-chain momentum score.
        
        Args:
            metrics: Raw metrics data
            asset: Asset type ("eth" or "sol")
            
        Returns:
            float: Momentum score (-1 to 1)
        """
        try:
            momentum_factors = []
            
            # Transaction growth
            if "transactions" in metrics and "daily_count" in metrics["transactions"]:
                daily_counts = metrics["transactions"]["daily_count"]
                if len(daily_counts) >= 7:
                    recent_avg = sum(daily_counts[-3:]) / 3
                    previous_avg = sum(daily_counts[-7:-3]) / 4
                    tx_momentum = (recent_avg - previous_avg) / previous_avg if previous_avg > 0 else 0
                    # Normalize to -1 to 1
                    tx_momentum = max(min(tx_momentum * 5, 1), -1)
                    momentum_factors.append(tx_momentum)
            
            # Network growth
            if "network" in metrics and "active_addresses" in metrics["network"]:
                active_addresses = metrics["network"]["active_addresses"]
                if len(active_addresses) >= 7:
                    recent_avg = sum(active_addresses[-3:]) / 3
                    previous_avg = sum(active_addresses[-7:-3]) / 4
                    address_momentum = (recent_avg - previous_avg) / previous_avg if previous_avg > 0 else 0
                    # Normalize to -1 to 1
                    address_momentum = max(min(address_momentum * 5, 1), -1)
                    momentum_factors.append(address_momentum)
            
            # Asset-specific factors
            if asset == "eth":
                # DeFi TVL growth
                if "defi" in metrics and "total_value_locked" in metrics["defi"]:
                    tvl = metrics["defi"]["total_value_locked"]
                    if len(tvl) >= 7:
                        recent_avg = sum(tvl[-3:]) / 3
                        previous_avg = sum(tvl[-7:-3]) / 4
                        tvl_momentum = (recent_avg - previous_avg) / previous_avg if previous_avg > 0 else 0
                        # Normalize to -1 to 1
                        tvl_momentum = max(min(tvl_momentum * 5, 1), -1)
                        momentum_factors.append(tvl_momentum)
            
            elif asset == "sol":
                # Staking growth
                if "staking" in metrics and "total_staked" in metrics["staking"]:
                    staked = metrics["staking"]["total_staked"]
                    if len(staked) >= 7:
                        recent_avg = sum(staked[-3:]) / 3
                        previous_avg = sum(staked[-7:-3]) / 4
                        staking_momentum = (recent_avg - previous_avg) / previous_avg if previous_avg > 0 else 0
                        # Normalize to -1 to 1
                        staking_momentum = max(min(staking_momentum * 5, 1), -1)
                        momentum_factors.append(staking_momentum)
            
            # Calculate overall momentum
            if momentum_factors:
                return sum(momentum_factors) / len(momentum_factors)
            else:
                return 0.0
            
        except Exception as e:
            self.logger.error(f"Error calculating on-chain momentum: {e}", exc_info=True)
            return 0.0
    
    def _calculate_on_chain_sentiment(self, metrics, asset):
        """
        Calculate on-chain sentiment score.
        
        Args:
            metrics: Raw metrics data
            asset: Asset type ("eth" or "sol")
            
        Returns:
            float: Sentiment score (-1 to 1)
        """
        try:
            sentiment_factors = []
            
            # Common factors
            
            # Transaction value trend
            if "transactions" in metrics and "avg_value" in metrics["transactions"]:
                avg_values = metrics["transactions"]["avg_value"]
                if len(avg_values) >= 7:
                    recent_avg = sum(avg_values[-3:]) / 3
                    previous_avg = sum(avg_values[-7:-3]) / 4
                    value_sentiment = (recent_avg - previous_avg) / previous_avg if previous_avg > 0 else 0
                    # Normalize to -1 to 1
                    value_sentiment = max(min(value_sentiment * 5, 1), -1)
                    sentiment_factors.append(value_sentiment)
            
            # New addresses trend
            if "network" in metrics and "new_addresses" in metrics["network"]:
                new_addresses = metrics["network"]["new_addresses"]
                if len(new_addresses) >= 7:
                    recent_avg = sum(new_addresses[-3:]) / 3
                    previous_avg = sum(new_addresses[-7:-3]) / 4
                    address_sentiment = (recent_avg - previous_avg) / previous_avg if previous_avg > 0 else 0
                    # Normalize to -1 to 1
                    address_sentiment = max(min(address_sentiment * 5, 1), -1)
                    sentiment_factors.append(address_sentiment)
            
            # Asset-specific factors
            if asset == "eth":
                # Whale activity
                if "whales" in metrics and "whale_transaction_count" in metrics["whales"]:
                    whale_txs = metrics["whales"]["whale_transaction_count"]
                    if len(whale_txs) >= 7:
                        recent_avg = sum(whale_txs[-3:]) / 3
                        previous_avg = sum(whale_txs[-7:-3]) / 4
                        whale_sentiment = (recent_avg - previous_avg) / previous_avg if previous_avg > 0 else 0
                        # Normalize to -1 to 1
                        whale_sentiment = max(min(whale_sentiment * 5, 1), -1)
                        sentiment_factors.append(whale_sentiment)
                
                # Gas price trend (inverse relationship)
                if "gas" in metrics and "avg_gas_price" in metrics["gas"]:
                    gas_prices = metrics["gas"]["avg_gas_price"]
                    if len(gas_prices) >= 7:
                        recent_avg = sum(gas_prices[-3:]) / 3
                        previous_avg = sum(gas_prices[-7:-3]) / 4
                        # Inverse relationship - lower gas prices are positive
                        gas_sentiment = (previous_avg - recent_avg) / previous_avg if previous_avg > 0 else 0
                        # Normalize to -1 to 1
                        gas_sentiment = max(min(gas_sentiment * 5, 1), -1)
                        sentiment_factors.append(gas_sentiment)
            
            elif asset == "sol":
                # NFT volume
                if "nft" in metrics and "daily_volume" in metrics["nft"]:
                    nft_volumes = metrics["nft"]["daily_volume"]
                    if len(nft_volumes) >= 7:
                        recent_avg = sum(nft_volumes[-3:]) / 3
                        previous_avg = sum(nft_volumes[-7:-3]) / 4
                        nft_sentiment = (recent_avg - previous_avg) / previous_avg if previous_avg > 0 else 0
                        # Normalize to -1 to 1
                        nft_sentiment = max(min(nft_sentiment * 5, 1), -1)
                        sentiment_factors.append(nft_sentiment)
                
                # Staking yield
                if "staking" in metrics and "staking_yield" in metrics["staking"]:
                    yields = metrics["staking"]["staking_yield"]
                    if len(yields) >= 7:
                        recent_avg = sum(yields[-3:]) / 3
                        previous_avg = sum(yields[-7:-3]) / 4
                        yield_sentiment = (recent_avg - previous_avg) / previous_avg if previous_avg > 0 else 0
                        # Normalize to -1 to 1
                        yield_sentiment = max(min(yield_sentiment * 5, 1), -1)
                        sentiment_factors.append(yield_sentiment)
            
            # Calculate overall sentiment
            if sentiment_factors:
                return sum(sentiment_factors) / len(sentiment_factors)
            else:
                return 0.0
            
        except Exception as e:
            self.logger.error(f"Error calculating on-chain sentiment: {e}", exc_info=True)
            return 0.0
    
    def _get_eth_transaction_metrics(self, days):
        """
        Get Ethereum transaction metrics from Etherscan.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: Transaction metrics
        """
        try:
            # Check if API key is available
            if not self.etherscan_api_key:
                self.logger.warning("Etherscan API key not provided, using simulated data")
                return self._get_simulated_eth_transaction_metrics(days)
            
            # Prepare API request
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days)
            
            params = {
                "module": "stats",
                "action": "dailytx",
                "startdate": start_date.strftime("%Y-%m-%d"),
                "enddate": end_date.strftime("%Y-%m-%d"),
                "sort": "asc",
                "apikey": self.etherscan_api_key
            }
            
            # Make API request
            response = requests.get(self.etherscan_base_url, params=params)
            data = response.json()
            
            if data["status"] != "1":
                self.logger.warning(f"Etherscan API error: {data.get('message', 'Unknown error')}")
                return self._get_simulated_eth_transaction_metrics(days)
            
            # Process response
            result = data["result"]
            
            # Extract daily transaction counts
            daily_count = [int(day["dailytx"]) for day in result]
            
            # Get average transaction value
            # This requires another API call
            params = {
                "module": "stats",
                "action": "dailyavgtxfee",
                "startdate": start_date.strftime("%Y-%m-%d"),
                "enddate": end_date.strftime("%Y-%m-%d"),
                "sort": "asc",
                "apikey": self.etherscan_api_key
            }
            
            response = requests.get(self.etherscan_base_url, params=params)
            data = response.json()
            
            if data["status"] != "1":
                self.logger.warning(f"Etherscan API error: {data.get('message', 'Unknown error')}")
                avg_value = [0] * len(daily_count)
            else:
                avg_value = [float(day["avgfee"]) for day in data["result"]]
            
            return {
                "daily_count": daily_count,
                "avg_value": avg_value
            }
            
        except Exception as e:
            self.logger.error(f"Error fetching ETH transaction metrics: {e}", exc_info=True)
            return self._get_simulated_eth_transaction_metrics(days)
    
    def _get_simulated_eth_transaction_metrics(self, days):
        """
        Generate simulated Ethereum transaction metrics for testing.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: Simulated transaction metrics
        """
        import numpy as np
        
        # Generate daily transaction counts with realistic values and some randomness
        base_count = 1_200_000  # Base daily transactions
        trend = np.linspace(0, 0.2, days)  # Slight upward trend
        noise = np.random.normal(0, 0.05, days)  # Random noise
        daily_count = [int(base_count * (1 + t + n)) for t, n in zip(trend, noise)]
        
        # Generate average transaction values
        base_value = 0.05  # Base average value in ETH
        value_trend = np.linspace(0, 0.1, days)  # Slight upward trend
        value_noise = np.random.normal(0, 0.02, days)  # Random noise
        avg_value = [base_value * (1 + t + n) for t, n in zip(value_trend, value_noise)]
        
        return {
            "daily_count": daily_count,
            "avg_value": avg_value
        }
    
    def _get_eth_gas_metrics(self, days):
        """
        Get Ethereum gas metrics from Etherscan.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: Gas metrics
        """
        try:
            # Check if API key is available
            if not self.etherscan_api_key:
                self.logger.warning("Etherscan API key not provided, using simulated data")
                return self._get_simulated_eth_gas_metrics(days)
            
            # Prepare API request
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days)
            
            params = {
                "module": "stats",
                "action": "dailyavggasprice",
                "startdate": start_date.strftime("%Y-%m-%d"),
                "enddate": end_date.strftime("%Y-%m-%d"),
                "sort": "asc",
                "apikey": self.etherscan_api_key
            }
            
            # Make API request
            response = requests.get(self.etherscan_base_url, params=params)
            data = response.json()
            
            if data["status"] != "1":
                self.logger.warning(f"Etherscan API error: {data.get('message', 'Unknown error')}")
                return self._get_simulated_eth_gas_metrics(days)
            
            # Process response
            result = data["result"]
            
            # Extract gas prices (convert from Wei to Gwei)
            avg_gas_price = [int(day["avgGasPrice_Wei"]) / 1e9 for day in result]
            
            return {
                "avg_gas_price": avg_gas_price
            }
            
        except Exception as e:
            self.logger.error(f"Error fetching ETH gas metrics: {e}", exc_info=True)
            return self._get_simulated_eth_gas_metrics(days)
    
    def _get_simulated_eth_gas_metrics(self, days):
        """
        Generate simulated Ethereum gas metrics for testing.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: Simulated gas metrics
        """
        import numpy as np
        
        # Generate average gas prices with realistic values and some randomness
        base_price = 30  # Base gas price in Gwei
        trend = np.linspace(0, 0.3, days)  # Upward trend
        noise = np.random.normal(0, 0.1, days)  # Random noise
        avg_gas_price = [base_price * (1 + t + n) for t, n in zip(trend, noise)]
        
        return {
            "avg_gas_price": avg_gas_price
        }
    
    def _get_eth_address_metrics(self, days):
        """
        Get Ethereum address metrics from Etherscan.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: Address metrics
        """
        # For now, use simulated data as this specific endpoint might not be directly available
        return self._get_simulated_eth_address_metrics(days)
    
    def _get_simulated_eth_address_metrics(self, days):
        """
        Generate simulated Ethereum address metrics for testing.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: Simulated address metrics
        """
        import numpy as np
        
        # Generate new addresses per day
        base_new = 100_000  # Base new addresses per day
        new_trend = np.linspace(0, 0.2, days)  # Upward trend
        new_noise = np.random.normal(0, 0.05, days)  # Random noise
        new_addresses = [int(base_new * (1 + t + n)) for t, n in zip(new_trend, new_noise)]
        
        # Generate active addresses per day
        base_active = 500_000  # Base active addresses per day
        active_trend = np.linspace(0, 0.15, days)  # Upward trend
        active_noise = np.random.normal(0, 0.03, days)  # Random noise
        active_addresses = [int(base_active * (1 + t + n)) for t, n in zip(active_trend, active_noise)]
        
        return {
            "new_addresses": new_addresses,
            "active_addresses": active_addresses
        }
    
    def _get_eth_defi_metrics(self, days):
        """
        Get Ethereum DeFi metrics.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: DeFi metrics
        """
        # For now, use simulated data as this might require multiple API calls or different sources
        return self._get_simulated_eth_defi_metrics(days)
    
    def _get_simulated_eth_defi_metrics(self, days):
        """
        Generate simulated Ethereum DeFi metrics for testing.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: Simulated DeFi metrics
        """
        import numpy as np
        
        # Generate total value locked (TVL) in billions of USD
        base_tvl = 40  # Base TVL in billions
        tvl_trend = np.linspace(0, 0.1, days)  # Upward trend
        tvl_noise = np.random.normal(0, 0.02, days)  # Random noise
        total_value_locked = [base_tvl * (1 + t + n) for t, n in zip(tvl_trend, tvl_noise)]
        
        # Generate daily trading volume in billions of USD
        base_volume = 2  # Base daily volume in billions
        volume_trend = np.linspace(0, 0.15, days)  # Upward trend
        volume_noise = np.random.normal(0, 0.05, days)  # Random noise
        daily_volume = [base_volume * (1 + t + n) for t, n in zip(volume_trend, volume_noise)]
        
        return {
            "total_value_locked": total_value_locked,
            "daily_volume": daily_volume
        }
    
    def _get_eth_whale_metrics(self, days):
        """
        Get Ethereum whale activity metrics.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: Whale metrics
        """
        # For now, use simulated data as this might require specialized API access
        return self._get_simulated_eth_whale_metrics(days)
    
    def _get_simulated_eth_whale_metrics(self, days):
        """
        Generate simulated Ethereum whale metrics for testing.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: Simulated whale metrics
        """
        import numpy as np
        
        # Generate whale transaction count (transactions > $1M)
        base_count = 200  # Base daily whale transactions
        count_trend = np.linspace(0, 0.2, days)  # Upward trend
        count_noise = np.random.normal(0, 0.1, days)  # Random noise
        whale_transaction_count = [int(base_count * (1 + t + n)) for t, n in zip(count_trend, count_noise)]
        
        # Generate whale balance changes in millions of USD
        base_balance = 50  # Base daily balance change in millions
        balance_trend = np.linspace(-0.1, 0.1, days)  # Mixed trend
        balance_noise = np.random.normal(0, 0.2, days)  # Random noise
        whale_balance_change = [base_balance * (t + n) for t, n in zip(balance_trend, balance_noise)]
        
        return {
            "whale_transaction_count": whale_transaction_count,
            "whale_balance_change": whale_balance_change
        }
    
    def _get_eth_network_metrics(self, days):
        """
        Get Ethereum network metrics.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: Network metrics
        """
        # Combine data from other metrics for network overview
        tx_metrics = self._get_eth_transaction_metrics(days)
        address_metrics = self._get_eth_address_metrics(days)
        
        return {
            "daily_transactions": tx_metrics.get("daily_count", []),
            "active_addresses": address_metrics.get("active_addresses", []),
            "new_addresses": address_metrics.get("new_addresses", [])
        }
    
    def _get_sol_transaction_metrics(self, days):
        """
        Get Solana transaction metrics from Solscan.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: Transaction metrics
        """
        try:
            # Check if API key is available
            if not self.solscan_api_key:
                self.logger.warning("Solscan API key not provided, using simulated data")
                return self._get_simulated_sol_transaction_metrics(days)
            
            # Prepare API request
            end_timestamp = int(datetime.now().timestamp())
            start_timestamp = int((datetime.now() - timedelta(days=days)).timestamp())
            
            headers = {
                "Accept": "application/json",
                "x-api-key": self.solscan_api_key
            }
            
            # Make API request for transaction count
            url = f"{self.solscan_base_url}/transaction/count"
            params = {
                "start_time": start_timestamp,
                "end_time": end_timestamp
            }
            
            response = requests.get(url, headers=headers, params=params)
            data = response.json()
            
            if "data" not in data:
                self.logger.warning(f"Solscan API error: {data.get('message', 'Unknown error')}")
                return self._get_simulated_sol_transaction_metrics(days)
            
            # Process response
            result = data["data"]
            
            # Extract daily transaction counts
            daily_count = [int(day["count"]) for day in result]
            
            # Get average transaction value
            # This might require additional API calls or calculations
            # For now, use simulated data for this part
            avg_value = self._get_simulated_sol_transaction_metrics(days)["avg_value"]
            
            return {
                "daily_count": daily_count,
                "avg_value": avg_value
            }
            
        except Exception as e:
            self.logger.error(f"Error fetching SOL transaction metrics: {e}", exc_info=True)
            return self._get_simulated_sol_transaction_metrics(days)
    
    def _get_simulated_sol_transaction_metrics(self, days):
        """
        Generate simulated Solana transaction metrics for testing.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: Simulated transaction metrics
        """
        import numpy as np
        
        # Generate daily transaction counts with realistic values and some randomness
        base_count = 50_000_000  # Base daily transactions (Solana has high TPS)
        trend = np.linspace(0, 0.15, days)  # Slight upward trend
        noise = np.random.normal(0, 0.03, days)  # Random noise
        daily_count = [int(base_count * (1 + t + n)) for t, n in zip(trend, noise)]
        
        # Generate average transaction values
        base_value = 0.01  # Base average value in SOL
        value_trend = np.linspace(0, 0.05, days)  # Slight upward trend
        value_noise = np.random.normal(0, 0.01, days)  # Random noise
        avg_value = [base_value * (1 + t + n) for t, n in zip(value_trend, value_noise)]
        
        return {
            "daily_count": daily_count,
            "avg_value": avg_value
        }
    
    def _get_sol_account_metrics(self, days):
        """
        Get Solana account metrics.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: Account metrics
        """
        # For now, use simulated data as this specific endpoint might not be directly available
        return self._get_simulated_sol_account_metrics(days)
    
    def _get_simulated_sol_account_metrics(self, days):
        """
        Generate simulated Solana account metrics for testing.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: Simulated account metrics
        """
        import numpy as np
        
        # Generate new accounts per day
        base_new = 50_000  # Base new accounts per day
        new_trend = np.linspace(0, 0.2, days)  # Upward trend
        new_noise = np.random.normal(0, 0.05, days)  # Random noise
        new_accounts = [int(base_new * (1 + t + n)) for t, n in zip(new_trend, new_noise)]
        
        # Generate active accounts per day
        base_active = 250_000  # Base active accounts per day
        active_trend = np.linspace(0, 0.15, days)  # Upward trend
        active_noise = np.random.normal(0, 0.03, days)  # Random noise
        active_accounts = [int(base_active * (1 + t + n)) for t, n in zip(active_trend, active_noise)]
        
        return {
            "new_accounts": new_accounts,
            "active_accounts": active_accounts
        }
    
    def _get_sol_staking_metrics(self, days):
        """
        Get Solana staking metrics.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: Staking metrics
        """
        # For now, use simulated data as this might require multiple API calls
        return self._get_simulated_sol_staking_metrics(days)
    
    def _get_simulated_sol_staking_metrics(self, days):
        """
        Generate simulated Solana staking metrics for testing.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: Simulated staking metrics
        """
        import numpy as np
        
        # Generate total staked SOL in millions
        base_staked = 350  # Base staked in millions of SOL
        staked_trend = np.linspace(0, 0.05, days)  # Upward trend
        staked_noise = np.random.normal(0, 0.01, days)  # Random noise
        total_staked = [base_staked * (1 + t + n) for t, n in zip(staked_trend, staked_noise)]
        
        # Generate staking yield percentage
        base_yield = 6.5  # Base yield percentage
        yield_trend = np.linspace(0, -0.1, days)  # Slight downward trend
        yield_noise = np.random.normal(0, 0.02, days)  # Random noise
        staking_yield = [base_yield * (1 + t + n) for t, n in zip(yield_trend, yield_noise)]
        
        # Generate validator count
        base_validators = 1800  # Base number of validators
        validator_trend = np.linspace(0, 0.03, days)  # Slight upward trend
        validator_noise = np.random.normal(0, 0.005, days)  # Random noise
        validator_count = [int(base_validators * (1 + t + n)) for t, n in zip(validator_trend, validator_noise)]
        
        return {
            "total_staked": total_staked,
            "staking_yield": staking_yield,
            "validator_count": validator_count
        }
    
    def _get_sol_nft_metrics(self, days):
        """
        Get Solana NFT metrics.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: NFT metrics
        """
        # For now, use simulated data as this might require specialized API access
        return self._get_simulated_sol_nft_metrics(days)
    
    def _get_simulated_sol_nft_metrics(self, days):
        """
        Generate simulated Solana NFT metrics for testing.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: Simulated NFT metrics
        """
        import numpy as np
        
        # Generate daily NFT volume in millions of USD
        base_volume = 5  # Base daily volume in millions
        volume_trend = np.linspace(0, -0.2, days)  # Downward trend
        volume_noise = np.random.normal(0, 0.1, days)  # Random noise
        daily_volume = [max(0.1, base_volume * (1 + t + n)) for t, n in zip(volume_trend, volume_noise)]
        
        # Generate daily NFT transactions
        base_txs = 20_000  # Base daily transactions
        txs_trend = np.linspace(0, -0.15, days)  # Downward trend
        txs_noise = np.random.normal(0, 0.05, days)  # Random noise
        daily_transactions = [int(max(1000, base_txs * (1 + t + n))) for t, n in zip(txs_trend, txs_noise)]
        
        return {
            "daily_volume": daily_volume,
            "daily_transactions": daily_transactions
        }
    
    def _get_sol_defi_metrics(self, days):
        """
        Get Solana DeFi metrics.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: DeFi metrics
        """
        # For now, use simulated data as this might require multiple API calls or different sources
        return self._get_simulated_sol_defi_metrics(days)
    
    def _get_simulated_sol_defi_metrics(self, days):
        """
        Generate simulated Solana DeFi metrics for testing.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: Simulated DeFi metrics
        """
        import numpy as np
        
        # Generate total value locked (TVL) in billions of USD
        base_tvl = 1.5  # Base TVL in billions
        tvl_trend = np.linspace(0, 0.1, days)  # Upward trend
        tvl_noise = np.random.normal(0, 0.03, days)  # Random noise
        total_value_locked = [base_tvl * (1 + t + n) for t, n in zip(tvl_trend, tvl_noise)]
        
        # Generate daily trading volume in millions of USD
        base_volume = 200  # Base daily volume in millions
        volume_trend = np.linspace(0, 0.15, days)  # Upward trend
        volume_noise = np.random.normal(0, 0.07, days)  # Random noise
        daily_volume = [base_volume * (1 + t + n) for t, n in zip(volume_trend, volume_noise)]
        
        return {
            "total_value_locked": total_value_locked,
            "daily_volume": daily_volume
        }
    
    def _get_sol_network_metrics(self, days):
        """
        Get Solana network metrics.
        
        Args:
            days: Number of days of historical data
            
        Returns:
            dict: Network metrics
        """
        # Combine data from other metrics for network overview
        tx_metrics = self._get_sol_transaction_metrics(days)
        account_metrics = self._get_sol_account_metrics(days)
        
        return {
            "daily_transactions": tx_metrics.get("daily_count", []),
            "active_addresses": account_metrics.get("active_accounts", []),
            "new_addresses": account_metrics.get("new_accounts", [])
        }


# Example usage
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Create collector
    collector = OnChainMetricsCollector(
        etherscan_api_key="YOUR_ETHERSCAN_API_KEY",
        solscan_api_key="YOUR_SOLSCAN_API_KEY"
    )
    
    # Get metrics for ETH
    eth_metrics = collector.get_metrics_for_trading("ETH")
    
    print("ETH On-Chain Metrics:")
    for key, value in eth_metrics.items():
        print(f"  {key}: {value}")
    
    # Get metrics for SOL
    sol_metrics = collector.get_metrics_for_trading("SOL")
    
    print("\nSOL On-Chain Metrics:")
    for key, value in sol_metrics.items():
        print(f"  {key}: {value}")
